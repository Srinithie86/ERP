﻿import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'generate_info.dart';

// â”€â”€â”€ Theme Constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const kTeal = Color(0xFF26A69A);
const kBg = Color(0xFFF4F6F8);
const kCard = Colors.white;
const kTextPrimary = Color(0xFF1A2332);
const kTextSecondary = Color(0xFF3D5481);
const kBorder = Color(0xFFE0E6ED);

// â”€â”€â”€ Status Colors â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const kPaidBg = Color(0xFF31AA28);
const kPendingBg = Color(0xFFBABD12);
const kDraftBg = Color(0xFF4098FA);

// â”€â”€â”€ Data Model â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
enum QuotationStatus { paid, pending, draft }

class QuotationItem {
  final String productName;
  final String amount;
  final String date;
  final String invoiceNo;
  final QuotationStatus status;

  const QuotationItem({
    required this.productName,
    required this.amount,
    required this.date,
    required this.invoiceNo,
    required this.status,
  });
}

final List<QuotationItem> allInvoices = [
  const QuotationItem(
    productName: 'L2 Managed Switch - 48 Port',
    amount: 'â‚¹4,200.00',
    date: '3 Apr 2026',
    invoiceNo: 'SPS/26-27/SI0006',
    status: QuotationStatus.paid,
  ),
  const QuotationItem(
    productName: 'L2 Managed Switch - 48 Port',
    amount: 'â‚¹4,200.00',
    date: '3 Apr 2026',
    invoiceNo: 'SPS/26-27/SI0006',
    status: QuotationStatus.pending,
  ),
  const QuotationItem(
    productName: 'L2 Managed Switch - 48 Port',
    amount: 'â‚¹4,200.00',
    date: '3 Apr 2026',
    invoiceNo: 'SPS/26-27/SI0006',
    status: QuotationStatus.draft,
  ),
  const QuotationItem(
    productName: 'L2 Managed Switch - 48 Port',
    amount: 'â‚¹4,200.00',
    date: '3 Apr 2026',
    invoiceNo: 'SPS/26-27/SI0006',
    status: QuotationStatus.pending,
  ),
  const QuotationItem(
    productName: 'L2 Managed Switch - 48 Port',
    amount: 'â‚¹4,200.00',
    date: '3 Apr 2026',
    invoiceNo: 'SPS/26-27/SI0006',
    status: QuotationStatus.paid,
  ),
];

// â”€â”€â”€ Main Page â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
class QuotationAllInvoicePage extends StatefulWidget {
  final String title;
  const QuotationAllInvoicePage({super.key, this.title = 'All Invoice'});

  @override
  State<QuotationAllInvoicePage> createState() => _QuotationAllInvoicePageState();
}

class _QuotationAllInvoicePageState extends State<QuotationAllInvoicePage> {
  int _selectedFilterIndex = 0;
  String _searchQuery = '';

  final List<String> _filters = ['ALL', 'SEND', 'PENDING', 'DRAFT'];

  @override
  void initState() {
    super.initState();
  }

  List<QuotationItem> get filteredInvoices {
    List<QuotationItem> result = allInvoices;
    if (_selectedFilterIndex == 1) {
      result = result.where((i) => i.status == QuotationStatus.paid).toList();
    } else if (_selectedFilterIndex == 2) {
      result = result.where((i) => i.status == QuotationStatus.pending).toList();
    } else if (_selectedFilterIndex == 3) {
      result = result.where((i) => i.status == QuotationStatus.draft).toList();
    }
    if (_searchQuery.isNotEmpty) {
      final q = _searchQuery.toLowerCase();
      result = result.where((i) {
        return i.productName.toLowerCase().contains(q) ||
            i.invoiceNo.toLowerCase().contains(q);
      }).toList();
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    // â”€â”€ Set on every build so hot reload / resume keeps it correct â”€â”€
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,  // black icons (Android)
      statusBarBrightness: Brightness.light,      // black icons (iOS)
    ));

    final mq = MediaQuery.of(context);
    final screenWidth = mq.size.width;
    final screenHeight = mq.size.height;
    final topPadding = mq.padding.top;      // status bar height
    final bottomPadding = mq.padding.bottom;

    final isTablet = screenWidth > 600;
    final hPad = isTablet ? screenWidth * 0.06 : screenWidth * 0.04;
    final cardPad = isTablet ? 18.0 : screenWidth * 0.038;
    final productFontSize = isTablet ? 15.0 : screenWidth * 0.036;
    final subFontSize = isTablet ? 13.0 : screenWidth * 0.03;
    final amountFontSize = isTablet ? 16.0 : screenWidth * 0.038;
    final filterFontSize = isTablet ? 13.0 : screenWidth * 0.03;
    final badgeFontSize = isTablet ? 12.0 : screenWidth * 0.028;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          _buildHeader(
            topPadding: topPadding,
            screenWidth: screenWidth,
            hPad: hPad,
            isTablet: isTablet,
          ),

          // â”€â”€ Body â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
          Expanded(
            child: Column(
              children: [
                SizedBox(height: screenHeight * 0.015),

                _buildSearchBar(hPad: hPad, screenWidth: screenWidth),

                SizedBox(height: screenHeight * 0.012),

                _buildFilterTabs(
                  hPad: hPad,
                  fontSize: filterFontSize,
                  screenWidth: screenWidth,
                ),

                SizedBox(height: screenHeight * 0.012),

                Expanded(
                  child: filteredInvoices.isEmpty
                      ? _buildEmptyState(screenWidth)
                      : ListView.builder(
                    padding: EdgeInsets.only(
                      left: hPad,
                      right: hPad,
                      bottom: bottomPadding + 16,
                    ),
                    itemCount: filteredInvoices.length,
                    itemBuilder: (ctx, i) => _buildInvoiceCard(
                      filteredInvoices[i],
                      cardPad: cardPad,
                      productFontSize: productFontSize,
                      subFontSize: subFontSize,
                      amountFontSize: amountFontSize,
                      badgeFontSize: badgeFontSize,
                      screenWidth: screenWidth,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader({
    required double topPadding,
    required double screenWidth,
    required double hPad,
    required bool isTablet,
  }) {
    final headerContentHeight = isTablet ? 60.0 : screenWidth * 0.145;
    final titleFontSize = isTablet ? 20.0 : screenWidth * 0.048;
    final btnFontSize = isTablet ? 14.0 : screenWidth * 0.033;
    final btnPadH = isTablet ? 16.0 : screenWidth * 0.035;
    final btnPadV = isTablet ? 10.0 : screenWidth * 0.022;
    final iconSize = isTablet ? 22.0 : screenWidth * 0.05;
    final backBtnSize = isTablet ? 36.0 : screenWidth * 0.082;

    return Container(
      color: kTeal,
      // topPadding = status bar height â†’ content starts below it
      padding: EdgeInsets.only(top: topPadding),
      child: SizedBox(
        height: headerContentHeight,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: hPad),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // â”€â”€ Back button â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
              GestureDetector(
                onTap: () => Navigator.maybePop(context),
                child: IconButton(
                  icon: Icon(
                    Icons.arrow_back_rounded,
                    color: Colors.white,
                    size: iconSize,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ),

              SizedBox(width: screenWidth * 0.03),

              // â”€â”€ Title â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
              Expanded(
                child: Text(
                  widget.title,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: titleFontSize,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.3,
                  ),
                ),
              ),

              // â”€â”€ + NEW button â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => QuotationGenerateInfoScreen(title: widget.title),
                    ),
                  );
                },
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: btnPadH,
                    vertical: btnPadV,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '+ NEW',
                    style: TextStyle(
                      color: kTeal,
                      fontSize: btnFontSize,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // â”€â”€ Search Bar â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  Widget _buildSearchBar({
    required double hPad,
    required double screenWidth,
  }) {
    final searchFontSize = screenWidth > 600 ? 14.0 : screenWidth * 0.034;
    final iconSize = screenWidth > 600 ? 20.0 : screenWidth * 0.045;
    final vertPad = screenWidth > 600 ? 14.0 : screenWidth * 0.03;

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: hPad),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: kBorder),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 6,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: TextField(
          onChanged: (v) => setState(() => _searchQuery = v),
          style: TextStyle(fontSize: searchFontSize, color: kTextPrimary),
          decoration: InputDecoration(
            hintText: 'Search Invoice or Customer...',
            hintStyle:
            TextStyle(fontSize: searchFontSize, color: kTextSecondary),
            prefixIcon:
            Icon(Icons.search_rounded, color: kTeal, size: iconSize),
            suffixIcon: _searchQuery.isNotEmpty
                ? IconButton(
              icon: Icon(Icons.clear,
                  size: iconSize * 0.85, color: kTextSecondary),
              onPressed: () => setState(() => _searchQuery = ''),
            )
                : null,
            filled: true,
            fillColor: Colors.white,
            isDense: true,
            contentPadding: EdgeInsets.symmetric(vertical: vertPad),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: kTeal, width: 1.5),
            ),
          ),
        ),
      ),
    );
  }

  // â”€â”€ Filter Tabs â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  Widget _buildFilterTabs({
    required double hPad,
    required double fontSize,
    required double screenWidth,
  }) {
    final tabPadH = screenWidth > 600 ? 20.0 : screenWidth * 0.045;
    final tabPadV = screenWidth > 600 ? 10.0 : screenWidth * 0.022;
    final radius = screenWidth > 600 ? 22.0 : screenWidth * 0.05;

    return SizedBox(
      height: screenWidth > 600 ? 44 : screenWidth * 0.1,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: hPad),
        itemCount: _filters.length,
        itemBuilder: (ctx, i) {
          final isActive = _selectedFilterIndex == i;
          return GestureDetector(
            onTap: () => setState(() => _selectedFilterIndex = i),
            child: Container(
              margin: EdgeInsets.only(right: screenWidth * 0.025),
              padding: EdgeInsets.symmetric(
                horizontal: tabPadH,
                vertical: tabPadV,
              ),
              decoration: BoxDecoration(
                color: isActive ? kTeal : Color(0xffA3E6E0),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isActive ? kTeal : kBorder,
                ),
                boxShadow: isActive
                    ? [
                  BoxShadow(
                    color: kTeal.withOpacity(0.3),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  )
                ]
                    : [],
              ),
              child: Text(
                _filters[i],
                style: TextStyle(
                  fontSize: fontSize,
                  fontWeight: FontWeight.w600,
                  color: isActive ? Colors.white : kTextSecondary,
                  letterSpacing: 0.3,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // â”€â”€ Invoice Card â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  Widget _buildInvoiceCard(
      QuotationItem item, {
        required double cardPad,
        required double productFontSize,
        required double subFontSize,
        required double amountFontSize,
        required double badgeFontSize,
        required double screenWidth,
      }) {
    final statusLabel = _statusLabel(item.status);
    final statusColor = _statusColor(item.status);
    final cardRadius = screenWidth > 600 ? 12.0 : screenWidth * 0.028;
    final marginB = screenWidth > 600 ? 12.0 : screenWidth * 0.025;
    final badgeFontSz = screenWidth > 600 ? 12.0 : screenWidth * 0.028;
    final badgeWidth = screenWidth > 600 ? 80.0 : screenWidth * 0.19;
    final badgeHeight = screenWidth > 600 ? 28.0 : screenWidth * 0.065;
    final badgeRadius = screenWidth > 600 ? 12.0 : screenWidth * 0.03;

    return Container(
      margin: EdgeInsets.only(bottom: marginB),
      decoration: BoxDecoration(
        color: Color(0xffF2F2F2),
        borderRadius: BorderRadius.circular(cardRadius),
        border: Border.all(color: kBorder),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(cardPad),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    item.productName,
                    style: TextStyle(
                      fontSize: productFontSize,
                      fontWeight: FontWeight.w700,
                      color: kTextPrimary,
                      height: 1.3,
                    ),
                  ),
                ),
                SizedBox(width: screenWidth * 0.02),
                Text(
                  item.amount,
                  style: TextStyle(
                    fontSize: amountFontSize,
                    fontWeight: FontWeight.w700,
                    color: Color(0xff005BBF),
                  ),
                ),
              ],
            ),
            SizedBox(height: screenWidth * 0.015),

            SizedBox(height: screenWidth * 0.015),
            Row(
              children: [
                Text(
                  item.date,
                  style: TextStyle(
                    fontSize: subFontSize,
                    color: kTextSecondary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(width: screenWidth * 0.03),
                Expanded(
                  child: Text(
                    item.invoiceNo,
                    style: TextStyle(
                      fontSize: subFontSize,
                      color: kTextSecondary,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Container(
                  width: badgeWidth,
                  height: badgeHeight,
                  decoration: BoxDecoration(
                    color: statusColor,
                    borderRadius: BorderRadius.circular(badgeRadius),
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    statusLabel,
                    style: TextStyle(
                      fontSize: badgeFontSz,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // â”€â”€ Empty State â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  Widget _buildEmptyState(double screenWidth) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.receipt_long_outlined,
              size: screenWidth * 0.15,
              color: kTextSecondary.withOpacity(0.35)),
          SizedBox(height: screenWidth * 0.03),
          Text('No invoices found',
              style: TextStyle(
                  fontSize: screenWidth * 0.038, color: kTextSecondary)),
        ],
      ),
    );
  }

  // â”€â”€ Helpers â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  String _statusLabel(QuotationStatus status) {
    switch (status) {
      case QuotationStatus.paid:
        return 'Paid';
      case QuotationStatus.pending:
        return 'Pending';
      case QuotationStatus.draft:
        return 'Draft';
    }
  }

  Color _statusColor(QuotationStatus status) {
    switch (status) {
      case QuotationStatus.paid:
        return kPaidBg;
      case QuotationStatus.pending:
        return kPendingBg;
      case QuotationStatus.draft:
        return kDraftBg;
    }
  }
}
