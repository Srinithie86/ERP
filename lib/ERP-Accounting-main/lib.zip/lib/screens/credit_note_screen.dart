import 'package:flutter/material.dart';
import 'placeholder_screen.dart';

class CreditNoteScreen extends StatelessWidget {
  const CreditNoteScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderScreen(title: 'Credit Note');
  }
}
