import 'package:flutter/material.dart';

import '../../screens/credit_note_screen.dart';
import '../../screens/notifications_screen.dart';
import '../../screens/profile_screen.dart';
import '../../screens/trial_balance_screen.dart';
import '../../screens/voucher_module/contra_voucher.dart';
import '../../screens/voucher_module/debit_voucher.dart';
import '../../screens/voucher_module/journal_voucher.dart';
import '../../screens/voucher_module/payment_voucher.dart';
import '../../screens/voucher_module/receipt_voucher.dart';
import '../app_colors.dart';

class DashboardDrawer extends StatelessWidget {
  const DashboardDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 24),
            color: AppColors.brand,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.25),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.person_rounded,
                    color: Colors.white,
                    size: 30,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Admin User',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 2),
                const Text(
                  'admin@supplier.com',
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: const [
                _DrawerItem(
                  icon: Icons.home_rounded,
                  label: 'Home',
                  active: true,
                ),
                _DrawerItem(
                  icon: Icons.money_rounded,
                  label: 'Credit Note',
                  page: CreditNoteScreen(),
                ),
                _DrawerItem(
                  icon: Icons.account_balance_wallet_rounded,
                  label: 'Debit Note',
                  page: DebitScreen(),
                ),
                _DropdownDrawerItem(
                  icon: Icons.folder_open_rounded,
                  label: 'Vouchers',
                  children: [
                    _DrawerItem(
                      icon: Icons.receipt_long_rounded,
                      label: 'Contra Voucher',
                      page: ContraVoucherScreen(),
                      isSubItem: true,
                    ),
                    _DrawerItem(
                      icon: Icons.menu_book_rounded,
                      label: 'Journal Voucher',
                      page: VoucherEntryRoot(),
                      isSubItem: true,
                    ),
                    _DrawerItem(
                      icon: Icons.payment_rounded,
                      label: 'Payment Voucher',
                      page: SupplierPaymentForm(),
                      isSubItem: true,
                    ),
                    _DrawerItem(
                      icon: Icons.book_rounded,
                      label: 'Receipt Voucher',
                      page: SupplierPaymentForm1(),
                      isSubItem: true,
                    ),
                  ],
                ),
                _DrawerItem(
                  icon: Icons.account_balance_rounded,
                  label: 'Trial Balance',
                  page: TrialBalanceScreen(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DropdownDrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final List<Widget> children;

  const _DropdownDrawerItem({
    required this.icon,
    required this.label,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 16),
          leading: Icon(icon, color: AppColors.text2, size: 20),
          title: Text(
            label,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w500,
              color: AppColors.text1,
            ),
          ),
          children: children,
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final Widget? page;
  final bool isSubItem;

  const _DrawerItem({
    required this.icon,
    required this.label,
    this.active = false,
    this.page,
    this.isSubItem = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        color: active
            ? AppColors.brand.withValues(alpha: 0.1)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        dense: true,
        contentPadding: EdgeInsets.only(left: isSubItem ? 48 : 16, right: 16),
        leading: Icon(
          icon,
          color: active ? AppColors.brand : AppColors.text2,
          size: 20,
        ),
        title: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: active ? FontWeight.w700 : FontWeight.w500,
            color: active ? AppColors.brand : AppColors.text1,
          ),
        ),
        onTap: () {
          Navigator.pop(context);
          if (page != null) {
            Navigator.push(context, MaterialPageRoute(builder: (_) => page!));
          }
        },
      ),
    );
  }
}
