import 'package:flutter/material.dart';
import 'package:crm/core/theme/app_theme.dart';
import 'package:crm/widgets/main_layout.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Total ERP CRM',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      // For testing, let's go straight to the Dashboard
      // In production, this would be LoginScreen()
      home: const MainLayout(), 
    );
  }
}

// In main_layout.dart, update the _screens list to include DashboardScreen
// Let's modify MainLayout now to properly display the Dashboard
