
import 'package:flutter/material.dart';
import 'package:service_ticket/core/size_utils.dart';

import '../core/app_colors.dart';
import '../data/app_data.dart';

class StandByScreen extends StatefulWidget {
  const StandByScreen({super.key});

  @override
  State<StandByScreen> createState() => _StandByScreenState();
}

class _StandByScreenState extends State<StandByScreen> {
  @override
  Widget build(BuildContext context) {
    final provider = AppData.instance;
    final available = provider.availableMachines;
    final inUse = provider.inUseMachines;
    final total = provider.totalMachineCount;
    final availableCount = provider.availableMachineCount;
    final inUseCount = provider.inUseMachineCount;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: AppColors.primary, size: 24.sp),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Stand by',
          style: TextStyle(
            color: AppColors.primary,
            fontSize: 20.sp,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(16.w),
              decoration: BoxDecoration(
                color: const Color(0xFFFFEBEE),
                borderRadius: BorderRadius.circular(12.r),
              ),
              child: Column(
                children: [
                  Text(
                    'Available Machine',
                    style: TextStyle(
                      color: const Color(0xFF1B5E20),
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  SizedBox(height: 18.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _CircularStat(
                        label: 'Total',
                        value: 1.0,
                        count: total,
                        color: Colors.green,
                      ),
                      _CircularStat(
                        label: 'Available',
                        value: total > 0 ? availableCount / total : 0,
                        count: availableCount,
                        color: Colors.blue,
                      ),
                      _CircularStat(
                        label: 'In Use',
                        value: total > 0 ? inUseCount / total : 0,
                        count: inUseCount,
                        color: Colors.red,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(height: 24.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Available Machines',
                  style: TextStyle(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
                InkWell(
                  onTap: () => _openAssignBottomSheet(context),
                  borderRadius: BorderRadius.circular(8.r),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 8.h),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF8E54E9), Color(0xFF4776E6)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.add, size: 16.sp, color: Colors.white),
                        SizedBox(width: 4.w),
                        Text(
                          'Assign',
                          style: TextStyle(
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12.h),
            ...available.map(
              (m) => _MachineListItem(
                name: '${m['breakerNo']} - ${m['serial']}',
                gradientColors: const [
                  Colors.white,
                  Color(0xCC66BB6A),
                  Color(0xFF43A047),
                ],
              ),
            ),
            SizedBox(height: 24.h),
            Text(
              'Machines in Use',
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w700,
                color: Colors.black87,
              ),
            ),
            SizedBox(height: 12.h),
            ...inUse.map((m) => _MachineInUseItem(machine: m)),
          ],
        ),
      ),
    );
  }

  Future<void> _openAssignBottomSheet(BuildContext context) async {
    final assigned = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => const _AssignMachineSheet(),
    );
    if (assigned == true && mounted) {
      setState(() {});
    }
  }
}

class _CircularStat extends StatelessWidget {
  const _CircularStat({
    required this.label,
    required this.value,
    required this.count,
    required this.color,
  });

  final String label;
  final double value;
  final int count;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              width: 58.w,
              height: 58.w,
              child: CircularProgressIndicator(
                value: value,
                strokeWidth: 5.w,
                backgroundColor: Colors.grey.shade300,
                valueColor: AlwaysStoppedAnimation<Color>(color),
              ),
            ),
            Container(
              width: 32.w,
              height: 32.w,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                shape: BoxShape.circle,
              ),
              child: Center(
                child: Text(
                  '$count',
                  style: TextStyle(
                    fontSize: 14.sp,
                    fontWeight: FontWeight.w800,
                    color: color,
                  ),
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 8.h),
        Text(
          label,
          style: TextStyle(
            fontSize: 13.sp,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }
}

class _MachineListItem extends StatelessWidget {
  const _MachineListItem({
    required this.name,
    required this.gradientColors,
  });

  final String name;
  final List<Color> gradientColors;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      width: double.infinity,
      height: 50.h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.r),
        gradient: LinearGradient(
          colors: gradientColors,
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: Center(
        child: Text(
          name,
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w700,
            color: Colors.black.withValues(alpha: 0.8),
          ),
        ),
      ),
    );
  }
}

class _MachineInUseItem extends StatefulWidget {
  const _MachineInUseItem({required this.machine});
  final Map<String, dynamic> machine;

  @override
  State<_MachineInUseItem> createState() => _MachineInUseItemState();
}

class _MachineInUseItemState extends State<_MachineInUseItem> {
  bool _isExpanded = false;

  String _formatDate(dynamic date) {
    if (date is DateTime) {
      return '${date.month}/${date.day}/${date.year.toString().substring(2)}';
    }
    return '--';
  }

  @override
  Widget build(BuildContext context) {
    final m = widget.machine;

    if (!_isExpanded) {
      return InkWell(
        onTap: () => setState(() => _isExpanded = true),
        child: Container(
          margin: EdgeInsets.only(bottom: 12.h),
          width: double.infinity,
          height: 50.h,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8.r),
            gradient: const LinearGradient(
              colors: [Colors.white, Color(0xCCEF5350), Color(0xFFE53935)],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                '${m['breakerNo']} - ${m['serial']} · In Use',
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w700,
                  color: Colors.black.withValues(alpha: 0.8),
                ),
              ),
              Positioned(
                right: 12.w,
                child: Icon(
                  Icons.keyboard_arrow_down_rounded,
                  size: 26.sp,
                  color: Colors.black87,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8.r),
        gradient: const LinearGradient(
          colors: [Colors.white, Color(0xFFF78FA7), Color(0xFFF14D67)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => setState(() => _isExpanded = false),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Center(
                    child: Text(
                      '${m['breakerNo']} - ${m['serial']} · In Use',
                      style: TextStyle(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.black87,
                      ),
                    ),
                  ),
                  Positioned(
                    right: 0,
                    child: Icon(
                      Icons.keyboard_arrow_up_rounded,
                      size: 26.sp,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              children: [
                _buildDetailRow(Icons.settings_suggest_rounded, const Color(0xFFF06292), 'Machine No', m['breakerNo'] ?? '--'),
                SizedBox(height: 10.h),
                _buildDetailRow(Icons.apps_rounded, const Color(0xFF4CAF50), 'Serial Number', m['serial'] ?? '--'),
                SizedBox(height: 10.h),
                _buildDetailRow(Icons.people_alt_rounded, const Color(0xFF5C6BC0), 'Customer', m['customerName'] ?? '--'),
                SizedBox(height: 10.h),
                _buildDetailRow(Icons.confirmation_number_rounded, const Color(0xFFFF9800), 'Ticket No', m['ticketNo'] ?? '--'),
                if ((m['charges'] ?? '').toString().isNotEmpty) ...[
                  SizedBox(height: 10.h),
                  _buildDetailRow(Icons.currency_rupee_rounded, const Color(0xFF009688), 'Charges', '₹${m['charges']}'),
                ],
              ],
            ),
          ),
          SizedBox(height: 14.h),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.w),
            child: const Divider(color: Colors.black38, height: 1),
          ),
          SizedBox(height: 12.h),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset('assets/calendar_icon.png', width: 24.sp, height: 24.sp),
                SizedBox(height: 12.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Given Date', style: TextStyle(fontSize: 14.sp, color: Colors.white, fontWeight: FontWeight.w600)),
                    Text(_formatDate(m['givenDate']), style: TextStyle(fontSize: 14.sp, color: Colors.white, fontWeight: FontWeight.w600)),
                  ],
                ),
                SizedBox(height: 10.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Returning Date', style: TextStyle(fontSize: 14.sp, color: Colors.white, fontWeight: FontWeight.w600)),
                    Text(_formatDate(m['returnDate']), style: TextStyle(fontSize: 14.sp, color: Colors.white, fontWeight: FontWeight.w600)),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 16.h),
        ],
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, Color iconColor, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 18.sp, color: iconColor),
        SizedBox(width: 12.w),
        Text(label, style: TextStyle(fontSize: 13.sp, color: Colors.black87, fontWeight: FontWeight.w500)),
        const Spacer(),
        Text(value, style: TextStyle(fontSize: 13.sp, color: const Color(0xFF004D40), fontWeight: FontWeight.w500)),
      ],
    );
  }
}

class _AssignMachineSheet extends StatefulWidget {
  const _AssignMachineSheet();

  @override
  State<_AssignMachineSheet> createState() => _AssignMachineSheetState();
}

class _AssignMachineSheetState extends State<_AssignMachineSheet> {
  final _ticketController = TextEditingController();
  final _customerController = TextEditingController();
  final _chargesController = TextEditingController();

  String? _selectedBreakerNo;
  String? _selectedTicketNo;
  DateTime? _givenDate;
  DateTime? _returnDate;
  bool _showAdditional = false;
  bool _submitted = false;

  @override
  void dispose() {
    _ticketController.dispose();
    _customerController.dispose();
    _chargesController.dispose();
    super.dispose();
  }

  bool _isFieldError(String? value) => _submitted && (value == null || value.trim().isEmpty);
  bool _isDateError(DateTime? date) => _submitted && date == null;
  bool _isDropdownError(String? value) => _submitted && (value == null || value.isEmpty);

  void _applyTicketSelection(AppData provider, String ticketNo) {
    final ticket = provider.tickets.firstWhere(
      (item) => '${item['id']}' == ticketNo,
      orElse: () => <String, dynamic>{},
    );
    _ticketController.text = ticketNo;
    _customerController.text = '${ticket['user'] ?? ''}';
  }

  Future<void> _pickDate(BuildContext context, bool isGiven) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: ColorScheme.light(primary: AppColors.primary),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        if (isGiven) {
          _givenDate = picked;
        } else {
          _returnDate = picked;
        }
      });
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return '';
    return '${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}/${date.year}';
  }

  void _handleSubmit() {
    setState(() => _submitted = true);

    final hasCustomer = _customerController.text.trim().isNotEmpty;
    final hasGiven = _givenDate != null;
    final hasReturn = _returnDate != null;
    final hasBreaker = _selectedBreakerNo != null;
    final hasTicket = _selectedTicketNo != null;

    if (!hasTicket || !hasCustomer || !hasGiven || !hasReturn || !hasBreaker) {
      return;
    }

    final provider = AppData.instance;
    final ticketNo = _selectedTicketNo!;
    provider.assignMachine(
      breakerNo: _selectedBreakerNo!,
      ticketNo: ticketNo,
      customerName: _customerController.text.trim(),
      jobNo: ticketNo,
      givenDate: _givenDate!,
      returnDate: _returnDate!,
      charges: _chargesController.text.trim().isEmpty ? null : _chargesController.text.trim(),
    );

    Navigator.pop(context, true);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Machine $_selectedBreakerNo assigned successfully'),
        backgroundColor: const Color(0xFF45C95A),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = AppData.instance;
    final breakers = provider.availableBreakerNumbers;
    final tickets = provider.pendingAndAssignedJobNumbers;
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      padding: EdgeInsets.only(bottom: bottomInset),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                margin: EdgeInsets.only(top: 12.h),
                width: 40.w,
                height: 4.h,
                decoration: BoxDecoration(
                  color: const Color(0xFFD1D5DB),
                  borderRadius: BorderRadius.circular(2.r),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20.w, 20.h, 20.w, 24.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildLabel('Ticket No', true),
                  SizedBox(height: 6.h),
                  _buildDropdown(
                    value: _selectedTicketNo,
                    hint: 'Select Ticket No',
                    items: tickets,
                    hasError: _isDropdownError(_selectedTicketNo),
                    onChanged: (val) {
                      if (val == null) return;
                      setState(() {
                        _selectedTicketNo = val;
                        _applyTicketSelection(provider, val);
                      });
                    },
                  ),
                  SizedBox(height: 16.h),
                  _buildLabel('Customer Name', true),
                  SizedBox(height: 6.h),
                  _buildTextField(
                    controller: _customerController,
                    hint: 'Thanusri',
                    hasError: _isFieldError(_customerController.text),
                    readOnly: true,
                  ),
                  SizedBox(height: 16.h),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildLabel('Date of Given', true),
                            SizedBox(height: 6.h),
                            _buildDateField(
                              date: _givenDate,
                              hasError: _isDateError(_givenDate),
                              onTap: () => _pickDate(context, true),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildLabel('Return Date', true),
                            SizedBox(height: 6.h),
                            _buildDateField(
                              date: _returnDate,
                              hasError: _isDateError(_returnDate),
                              onTap: () => _pickDate(context, false),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 18.h),

                   // ─── Breaker No ───
                  _buildLabel('Breaker No', true),
                  SizedBox(height: 6.h),
                  _buildDropdown(
                    value: _selectedBreakerNo,
                    hint: 'Select Breaker',
                    items: breakers,
                    hasError: _isDropdownError(_selectedBreakerNo),
                    onChanged: (val) => setState(() => _selectedBreakerNo = val),
                  ),
                  SizedBox(height: 16.h),

                  // ─── Additional Options Toggle ───
                  SizedBox(height: 16.h),
                  InkWell(
                    onTap: () => setState(() => _showAdditional = !_showAdditional),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(child: Container(height: 1, color: const Color(0xFFD1D5DB))),
                        SizedBox(width: 8.w),
                        Icon(Icons.tune, size: 16.sp, color: const Color(0xFF6B7280)),
                        SizedBox(width: 6.w),
                        Text(
                          'ADDITIONAL OPTIONS',
                          style: TextStyle(
                            fontSize: 11.sp,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF6B7280),
                            letterSpacing: 0.5,
                          ),
                        ),
                        SizedBox(width: 6.w),
                        Icon(
                          _showAdditional ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                          size: 20.sp,
                          color: const Color(0xFF6B7280),
                        ),
                        SizedBox(width: 8.w),
                        Expanded(child: Container(height: 1, color: const Color(0xFFD1D5DB))),
                      ],
                    ),
                  ),

                  // ─── Additional Fields ───
                  if (_showAdditional) ...[
                    SizedBox(height: 16.h),

                    // Charges (Optional)
                    _buildLabel('Charges', false),
                    SizedBox(height: 6.h),
                    _buildTextField(
                      controller: _chargesController,
                      hint: 'Enter charges (optional)',
                      hasError: false,
                      keyboardType: TextInputType.number,
                    ),
                  ],
                  SizedBox(height: 32.h),
                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 48.h,
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(context),
                            style: OutlinedButton.styleFrom(
                              side: BorderSide(color: AppColors.primary, width: 1.5),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              foregroundColor: AppColors.primary,
                            ),
                            child: Text(
                              'Cancel',
                              style: TextStyle(
                                fontSize: 15.sp,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 16.w),
                      Expanded(
                        child: SizedBox(
                          height: 48.h,
                          child: ElevatedButton(
                            onPressed: _handleSubmit,
                            style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.zero,
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              elevation: 0,
                            ),
                            child: Ink(
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  colors: [Color(0xFF8E54E9), Color(0xFF4776E6)],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              child: Container(
                                alignment: Alignment.center,
                                child: Text(
                                  'Assign',
                                  style: TextStyle(
                                    fontSize: 15.sp,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLabel(String text, bool isMandatory) {
    return RichText(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontSize: 13.sp,
          fontWeight: FontWeight.w600,
          color: Colors.black87,
        ),
        children: isMandatory
            ? [TextSpan(text: ' *', style: TextStyle(color: Colors.red, fontSize: 13.sp))]
            : [],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    required bool hasError,
    TextInputType keyboardType = TextInputType.text,
    bool readOnly = false,
  }) {
    return TextField(
      controller: controller,
      keyboardType: keyboardType,
      readOnly: readOnly,
      onChanged: (_) => setState(() {}),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(fontSize: 14.sp, color: const Color(0xFF9CA3AF)),
        filled: true,
        fillColor: const Color(0xFFF9FAFB),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.r),
          borderSide: BorderSide(
            color: hasError ? Colors.red : const Color(0xFFE5E7EB),
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.r),
          borderSide: BorderSide(
            color: hasError ? Colors.red : const Color(0xFFE5E7EB),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.r),
          borderSide: BorderSide(
            color: hasError ? Colors.red : AppColors.primary,
            width: 1.5,
          ),
        ),
        contentPadding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
      ),
    );
  }

  Widget _buildDateField({
    required DateTime? date,
    required bool hasError,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8.r),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
        decoration: BoxDecoration(
          color: const Color(0xFFF9FAFB),
          borderRadius: BorderRadius.circular(8.r),
          border: Border.all(
            color: hasError ? Colors.red : const Color(0xFFE5E7EB),
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                date != null ? _formatDate(date) : 'Select',
                style: TextStyle(
                  fontSize: 14.sp,
                  color: date != null ? Colors.black87 : const Color(0xFF9CA3AF),
                ),
              ),
            ),
            Image.asset('assets/calendar_icon.png', width: 18.sp, height: 18.sp),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown({
    required String? value,
    required String hint,
    required List<String> items,
    required bool hasError,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 14.w),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(
          color: hasError ? Colors.red : const Color(0xFFE5E7EB),
        ),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          hint: Text(hint, style: TextStyle(fontSize: 14.sp, color: const Color(0xFF9CA3AF))),
          isExpanded: true,
          icon: Icon(Icons.keyboard_arrow_down_rounded, color: const Color(0xFF6B7280)),
          items: items
              .map(
                (item) => DropdownMenuItem(
                  value: item,
                  child: Text(item, style: TextStyle(fontSize: 14.sp)),
                ),
              )
              .toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}
