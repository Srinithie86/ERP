import 'package:flutter/material.dart';
import 'package:service_ticket/core/size_utils.dart';

import '../../../core/app_colors.dart';
import '../../../data/app_data.dart';
import 'check_in_step_three_screen.dart';
import 'check_in_widgets.dart';

class CheckInStepTwoScreen extends StatefulWidget {
  const CheckInStepTwoScreen({super.key});

  @override
  State<CheckInStepTwoScreen> createState() => _CheckInStepTwoScreenState();
}

class _CheckInStepTwoScreenState extends State<CheckInStepTwoScreen> {
  late final TextEditingController _descriptionController;
  late final TextEditingController _chargeController;
  late final TextEditingController _partController;
  late final TextEditingController _quantityController;
  late final TextEditingController _partCodeController;

  final List<Map<String, String>> _spareLines = [];
  bool _showSpareDetails = false;
  bool _submitted = false;
  String _workStatus = 'Completed';
  DateTime? _nextVisitDate;

  final List<String> _partOptions = [
    'R22 Gas',
    'R222',
    'Compressor',
    'Capacitor',
    'PCB Board',
    'Sensor',
  ];

  final Map<String, String> _partCodeMap = {
    'R22 Gas': '113332',
    'R222': '113333',
    'Compressor': '224410',
    'Capacitor': '224411',
    'PCB Board': '224412',
    'Sensor': '224413',
  };

  @override
  void initState() {
    super.initState();
    final flow = AppData.instance;
    _descriptionController = TextEditingController(text: flow.workDescription);
    _chargeController = TextEditingController(text: flow.serviceChargeInput);
    _nextVisitDate = flow.nextVisitDate;

    final existingLines = (flow.job['spareLines'] as List)
        .map((item) => Map<String, String>.from(item as Map))
        .toList();
    if (existingLines.isNotEmpty) {
      _spareLines.addAll(existingLines);
    }

    final initialPart = _partOptions.first;
    _partController = TextEditingController(text: initialPart);
    _quantityController = TextEditingController(text: '1');
    _partCodeController = TextEditingController(text: _partCodeMap[initialPart] ?? '113332');
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    _chargeController.dispose();
    _partController.dispose();
    _quantityController.dispose();
    _partCodeController.dispose();
    super.dispose();
  }

  void _persistSpareLines(AppData flow) {
    flow.setSpareLines(List<Map<String, String>>.from(_spareLines));
  }

  void _addSpareLine(AppData flow) {
    final name = _partController.text.trim();
    final quantity = _quantityController.text.trim();
    final partCode = _partCodeController.text.trim();
    if (name.isEmpty || quantity.isEmpty || partCode.isEmpty) return;

    setState(() {
      _spareLines.add({
        'name': name,
        'quantity': quantity,
        'partCode': partCode,
      });
      _showSpareDetails = false;
      _quantityController.text = '1';
    });
    _persistSpareLines(flow);
  }

  String _formatNextVisitDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  Future<void> _pickNextVisitDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _nextVisitDate ?? now.add(const Duration(days: 1)),
      firstDate: now,
      lastDate: DateTime(now.year + 2),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: ColorScheme.light(primary: AppColors.primary),
        ),
        child: child!,
      ),
    );
    if (picked == null) return;
    setState(() => _nextVisitDate = picked);
  }

  @override
  Widget build(BuildContext context) {
    final flow = AppData.instance;
    final chargeInvalid = _submitted && _chargeController.text.trim().isEmpty;
    final beforeInvalid = _submitted && flow.beforeImageBytes == null;
    final afterInvalid = _submitted && flow.afterImageBytes == null;
    final nextVisitInvalid =
        _submitted && _workStatus == 'Pending' && _nextVisitDate == null;

    return CheckInScaffold(
      title: 'Service Form',
      actionLabel: 'Save & Check Out',
      onAction: () {
        setState(() => _submitted = true);
        flow.serviceChargeInput = _chargeController.text.trim();
        flow.workStatus = _workStatus;
        flow.nextVisitDate = _workStatus == 'Pending' ? _nextVisitDate : null;
        flow.updateJob({
          'serviceCharge': flow.serviceChargeInput,
          'nextVisitDate': flow.nextVisitDate == null
              ? ''
              : _formatNextVisitDate(flow.nextVisitDate!),
        });
        _persistSpareLines(flow);
        final hasError =
            _chargeController.text.trim().isEmpty ||
            flow.beforeImageBytes == null ||
            flow.afterImageBytes == null ||
            (_workStatus == 'Pending' && _nextVisitDate == null);
        if (hasError) {
          return;
        }
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const CheckInStepThreeScreen()),
        );
      },
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const WorkflowIndicator(currentStep: 3),
          SizedBox(height: 16.h),
          Text(
            'Work Description',
            style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 8.h),
          TextField(
            controller: _descriptionController,
            minLines: 4,
            maxLines: 4,
            onChanged: (value) => flow.workDescription = value,
            decoration: InputDecoration(
              hintText: 'Describe the work you performed',
              hintStyle: TextStyle(fontSize: 12.sp, color: const Color(0xFF98A2B3)),
              filled: true,
              fillColor: const Color(0xFFF1F4F9),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.r),
                borderSide: BorderSide.none,
              ),
              contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
            ),
          ),
          SizedBox(height: 16.h),
          InkWell(
            onTap: () => setState(() => _showSpareDetails = !_showSpareDetails),
            borderRadius: BorderRadius.circular(10.r),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
              decoration: BoxDecoration(
                color: const Color(0xFFF1F4F9),
                borderRadius: BorderRadius.circular(10.r),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      'Spare Parts Used',
                      style: TextStyle(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Text(
                    'Leave empty if none',
                    style: TextStyle(fontSize: 10.sp, color: const Color(0xFF667085)),
                  ),
                  SizedBox(width: 8.w),
                  Icon(
                    _showSpareDetails ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded,
                    size: 22.sp,
                    color: Colors.black87,
                  ),
                ],
              ),
            ),
          ),
          AnimatedCrossFade(
            duration: const Duration(milliseconds: 220),
            crossFadeState: _showSpareDetails ? CrossFadeState.showSecond : CrossFadeState.showFirst,
            firstChild: const SizedBox.shrink(),
            secondChild: Padding(
              padding: EdgeInsets.only(top: 12.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(14.r),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(color: const Color(0xFFE6EAF2)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Select Part',
                          style: TextStyle(
                            fontSize: 13.sp,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF445B87),
                          ),
                        ),
                        SizedBox(height: 8.h),
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.symmetric(horizontal: 12.w),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF1F4F9),
                            borderRadius: BorderRadius.circular(10.r),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: _partController.text.isEmpty ? _partOptions.first : _partController.text,
                              isExpanded: true,
                              icon: const Icon(Icons.keyboard_arrow_down_rounded),
                              items: _partOptions
                                  .map(
                                    (part) => DropdownMenuItem<String>(
                                      value: part,
                                      child: Text(
                                        part,
                                        style: TextStyle(fontSize: 13.sp),
                                      ),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (value) {
                                if (value == null) return;
                                setState(() {
                                  _partController.text = value;
                                  _partCodeController.text = _partCodeMap[value] ?? _partCodeController.text;
                                });
                              },
                            ),
                          ),
                        ),
                        SizedBox(height: 12.h),
                        Row(
                          children: [
                            Expanded(
                              child: _SpareField(
                                label: 'Quantity',
                                controller: _quantityController,
                              ),
                            ),
                            SizedBox(width: 12.w),
                            Expanded(
                              child: _SpareField(
                                label: 'Part Code',
                                controller: _partCodeController,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 14.h),
                        SizedBox(
                          width: double.infinity,
                          height: 44.h,
                          child: ElevatedButton(
                            onPressed: () => _addSpareLine(flow),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.primary,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              elevation: 0,
                            ),
                            child: Text(
                              'Add Spare',
                              style: TextStyle(
                                fontSize: 13.sp,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_spareLines.isNotEmpty) ...[
            SizedBox(height: 12.h),
            ..._spareLines.asMap().entries.map((entry) {
              final index = entry.key;
              final line = entry.value;
              return Padding(
                padding: EdgeInsets.only(bottom: 10.h),
                child: Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(12.r),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF8FAFF),
                    borderRadius: BorderRadius.circular(10.r),
                    border: Border.all(color: const Color(0xFFDCE3F7)),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${index + 1}. ${line['name']}',
                          style: TextStyle(
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF445B87),
                          ),
                        ),
                      ),
                      Text(
                        'Qty ${line['quantity']}',
                        style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFF2F4FB4),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ],
          SizedBox(height: 16.h),
          Text(
            'Upload  Before Image',
            style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 8.h),
          UploadBox(
            caption: 'JPG, PNG or PDF (Max 5MB)',
            fileName: flow.beforeImageName.isNotEmpty ? flow.beforeImageName : null,
            imageBytes: flow.beforeImageBytes,
            isInvalid: beforeInvalid,
            onTap: () async {
              final file = await UploadBox.pickImage(context);
              if (file != null) {
                final bytes = await file.readAsBytes();
                setState(() {
                  flow.beforeImageName = file.path.split('/').last;
                  flow.beforeImagePath = file.path;
                  flow.beforeImageBytes = bytes;
                });
              }
            },
          ),
          SizedBox(height: 16.h),
          Text(
            'Upload  After Image',
            style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 8.h),
          UploadBox(
            caption: 'JPG, PNG or PDF (Max 5MB)',
            fileName: flow.afterImageName.isNotEmpty ? flow.afterImageName : null,
            imageBytes: flow.afterImageBytes,
            isInvalid: afterInvalid,
            onTap: () async {
              final file = await UploadBox.pickImage(context);
              if (file != null) {
                final bytes = await file.readAsBytes();
                setState(() {
                  flow.afterImageName = file.path.split('/').last;
                  flow.afterImagePath = file.path;
                  flow.afterImageBytes = bytes;
                });
              }
            },
          ),
          SizedBox(height: 16.h),
          Text(
            'Service charge',
            style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 8.h),
          TextField(
            controller: _chargeController,
            keyboardType: TextInputType.number,
            onChanged: (value) => flow.serviceChargeInput = value,
            decoration: InputDecoration(
              hintText: '1',
              filled: true,
              fillColor: const Color(0xFFF1F4F9),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.r),
                borderSide: BorderSide(color: chargeInvalid ? const Color(0xFFD92D20) : Colors.transparent),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.r),
                borderSide: BorderSide(color: chargeInvalid ? const Color(0xFFD92D20) : Colors.transparent),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10.r),
                borderSide: BorderSide(color: chargeInvalid ? const Color(0xFFD92D20) : AppColors.primary),
              ),
              contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
            ),
          ),
          SizedBox(height: 16.h),
          Text(
            'Work Status',
            style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 8.h),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 12.w),
            decoration: BoxDecoration(
              color: const Color(0xFFF1F4F9),
              borderRadius: BorderRadius.circular(10.r),
              border: Border.all(color: const Color(0xFFE6EAF2)),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _workStatus,
                isExpanded: true,
                items: const [
                  DropdownMenuItem(value: 'Completed', child: Text('Completed')),
                  DropdownMenuItem(value: 'Pending', child: Text('Pending')),
                ],
                onChanged: (value) {
                  if (value == null) return;
                  setState(() {
                    _workStatus = value;
                    if (value == 'Completed') {
                      _nextVisitDate = null;
                    }
                  });
                  flow.workStatus = value;
                },
              ),
            ),
          ),
          if (_workStatus == 'Pending') ...[
            SizedBox(height: 16.h),
            Text(
              'Next Visit Date',
              style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 8.h),
            InkWell(
              onTap: _pickNextVisitDate,
              borderRadius: BorderRadius.circular(10.r),
              child: Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
                decoration: BoxDecoration(
                  color: const Color(0xFFF1F4F9),
                  borderRadius: BorderRadius.circular(10.r),
                  border: Border.all(
                    color: nextVisitInvalid
                        ? const Color(0xFFD92D20)
                        : const Color(0xFFE6EAF2),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        _nextVisitDate == null
                            ? 'Select next visit date'
                            : _formatNextVisitDate(_nextVisitDate!),
                        style: TextStyle(
                          fontSize: 13.sp,
                          color: _nextVisitDate == null
                              ? const Color(0xFF98A2B3)
                              : const Color(0xFF445B87),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    Image.asset(
                      'assets/calendar_icon.png',
                      width: 20.sp,
                      height: 20.sp,
                    ),
                  ],
                ),
              ),
            ),
          ],
          SizedBox(height: 16.h),
        ],
      ),
    );
  }
}

class _SpareField extends StatelessWidget {
  const _SpareField({
    required this.label,
    required this.controller,
  });

  final String label;
  final TextEditingController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            fontSize: 13.sp,
            fontWeight: FontWeight.w700,
            color: const Color(0xFF445B87),
          ),
        ),
        SizedBox(height: 8.h),
        TextField(
          controller: controller,
          decoration: InputDecoration(
            filled: true,
            fillColor: const Color(0xFFF1F4F9),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10.r),
              borderSide: BorderSide.none,
            ),
            contentPadding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
          ),
        ),
      ],
    );
  }
}
