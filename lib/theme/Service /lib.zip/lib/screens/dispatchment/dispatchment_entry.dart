import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:service_ticket/core/size_utils.dart';

import '../../Widgets/app_status_bar_wrapper.dart';
import '../../core/app_colors.dart';
import '../../data/app_data.dart';
import 'dispatchment_history.dart';

class DispatchmentEntryScreen extends StatefulWidget {
  final VoidCallback? onBack;
  
  const DispatchmentEntryScreen({super.key, this.onBack});

  @override
  State<DispatchmentEntryScreen> createState() => _DispatchmentEntryScreenState();
}

class _DispatchmentEntryScreenState extends State<DispatchmentEntryScreen> {
  static const _parcels = ['Parcel - 001', 'Parcel - 002', 'Parcel - 003', 'Parcel - 004'];
  static const _modes = ['Bus', 'Travels', 'Courier', 'Private Vehicle'];

  final Map<String, Map<String, String>> _parcelData = {
    'Parcel - 001': {'name': 'Tamilarasi', 'phone': '9876543210', 'address': 'Irugur, Ondipudur'},
    'Parcel - 002': {'name': 'Swamya', 'phone': '9123456780', 'address': 'Peelamedu, Coimbatore'},
    'Parcel - 003': {'name': 'Ahamed', 'phone': '9345678901', 'address': 'Saibaba Colony, Coimbatore'},
    'Parcel - 004': {'name': 'Revathi', 'phone': '9988776655', 'address': 'Ramanathapuram, Coimbatore'},
  };

  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  final _phoneFocus = FocusNode();

  String? _parcel = _parcels.first;
  String? _mode = _modes.first;
  DateTime? _transportDate;
  DateTime? _expectedDate;
  TimeOfDay? _dispatchTime;
  String _period = 'AM';
  bool _showDetails = true;
  bool _submitted = false;
  File? _image;
  String? _imagePath;

  @override
  void initState() {
    super.initState();
    _applyParcel(_parcel!);
    _dispatchTime = TimeOfDay.now();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    _notesCtrl.dispose();
    _phoneFocus.dispose();
    super.dispose();
  }

  void _applyParcel(String parcel) {
    final data = _parcelData[parcel] ?? <String, String>{};
    _nameCtrl.text = data['name'] ?? '';
    _phoneCtrl.text = data['phone'] ?? '';
    _addressCtrl.text = data['address'] ?? '';
  }

  String _formatDate(DateTime date) => '${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}/${date.year}';

  String _formatTime(TimeOfDay time) {
    final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
    return '$hour:${time.minute.toString().padLeft(2, '0')}';
  }

  bool get _phoneValid => _phoneCtrl.text.trim().length == 10;

  bool get _hasErrors =>
      _parcel == null ||
      _mode == null ||
      _transportDate == null ||
      _expectedDate == null ||
      _dispatchTime == null ||
      _nameCtrl.text.trim().isEmpty ||
      !_phoneValid ||
      _addressCtrl.text.trim().isEmpty ||
      _image == null;

  Color _border(bool invalid) => invalid && _submitted ? const Color(0xFFD92D20) : const Color(0xFFDDE3EF);

  Future<void> _pickDate({required bool expected}) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: expected ? (_expectedDate ?? _transportDate ?? DateTime.now()) : (_transportDate ?? DateTime.now()),
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
    );
    if (picked == null) return;
    setState(() => expected ? _expectedDate = picked : _transportDate = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: _dispatchTime ?? TimeOfDay.now());
    if (picked == null) return;
    setState(() {
      _dispatchTime = picked;
      _period = picked.period == DayPeriod.am ? 'AM' : 'PM';
    });
  }

  Future<void> _pickImage() async {
    final source = await showModalBottomSheet<ImageSource>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.camera_alt_rounded),
              title: const Text('Camera'),
              onTap: () => Navigator.of(sheetContext).pop(ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_rounded),
              title: const Text('Gallery'),
              onTap: () => Navigator.of(sheetContext).pop(ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    final picked = await ImagePicker().pickImage(source: source, imageQuality: 85);
    if (picked == null) return;
    setState(() {
      _image = File(picked.path);
      _imagePath = picked.path;
    });
  }

  Future<void> _submit() async {
    setState(() => _submitted = true);
    if (_hasErrors) return;
    await _showOtpSheet();
  }

  Future<void> _showOtpSheet() async {
    final codeCtrl = TextEditingController();
    final codeFocus = FocusNode();
    final appData = AppData.instance;
    final parcel = _parcel ?? _parcels.first;
    final mode = _mode ?? _modes.first;
    final transport = _transportDate ?? DateTime.now();
    final expected = _expectedDate ?? transport;
    final dispatchTime = _dispatchTime ?? TimeOfDay.now();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        Future<void> finish() async {
          codeFocus.unfocus();
          appData.confirmDispatch(
            DispatchmentRecord(
              dispatchId: appData.nextDispatchId(),
              parcelNo: parcel,
              transferMode: mode,
              transportDate: _formatDate(transport),
              expectedDelivery: _formatDate(expected),
              dispatchTime: '${_formatTime(dispatchTime)} $_period',
              contactName: _nameCtrl.text.trim(),
              phone: '+91 ${_phoneCtrl.text.trim()}',
              address: _addressCtrl.text.trim(),
              notes: _notesCtrl.text.trim().isEmpty ? 'No special instructions' : _notesCtrl.text.trim(),
              status: 'Dispatched',
              attachmentPath: _imagePath,
            ),
          );
          Navigator.of(sheetContext).pop();
          Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const DispatchmentHistoryScreen()));
        }

        return ValueListenableBuilder<TextEditingValue>(
          valueListenable: codeCtrl,
          builder: (_, value, _) {
            final digits = value.text.replaceAll(RegExp(r'[^0-9]'), '');
            final canVerify = digits.length == 6;
            return Container(
              padding: EdgeInsets.fromLTRB(18.w, 18.h, 18.w, MediaQuery.of(sheetContext).viewInsets.bottom + 20.h),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(28.r)),
              ),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(width: 44.w, height: 4.h, decoration: BoxDecoration(color: const Color(0xFFD0D5DD), borderRadius: BorderRadius.circular(20.r))),
                    SizedBox(height: 18.h),
                    Text('Happy code sent !', style: TextStyle(fontSize: 22.sp, fontWeight: FontWeight.w700, color: const Color(0xFF1E8D43))),
                    SizedBox(height: 8.h),
                    Text('Ask customer to share the 6 - digit code', textAlign: TextAlign.center, style: TextStyle(fontSize: 12.sp, color: const Color(0xFF667085))),
                    SizedBox(height: 18.h),
                    Text('ENTER HAPPY CODE', style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w800)),
                    SizedBox(height: 14.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: List.generate(6, (index) {
                        final digit = index < digits.length ? digits[index] : '';
                        return Container(
                          width: 40.w,
                          height: 48.h,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8.r),
                            border: Border.all(color: const Color(0xFF7A92E8), width: 1.2),
                          ),
                          child: Text(digit, style: TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w700, color: AppColors.primary)),
                        );
                      }),
                    ),
                    SizedBox(height: 10.h),
                    SizedBox(
                      height: 1,
                      child: TextField(
                        controller: codeCtrl,
                        focusNode: codeFocus,
                        autofocus: true,
                        keyboardType: TextInputType.number,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(6)],
                        decoration: const InputDecoration(border: InputBorder.none, isCollapsed: true, counterText: ''),
                        style: const TextStyle(fontSize: 1, color: Colors.transparent),
                        cursorColor: Colors.transparent,
                      ),
                    ),
                    SizedBox(height: 18.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Resend OTP in', style: TextStyle(fontSize: 13.sp, color: const Color(0xFF2644A6), decoration: TextDecoration.underline)),
                        Text('30 Sec', style: TextStyle(fontSize: 13.sp, fontWeight: FontWeight.w700, color: const Color(0xFF2644A6))),
                      ],
                    ),
                    SizedBox(height: 24.h),
                    SizedBox(
                      width: double.infinity,
                      height: 52.h,
                      child: ElevatedButton(
                        onPressed: canVerify ? finish : null,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF1E8D43),
                          disabledBackgroundColor: const Color(0xFFC7D5C8),
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
                        ),
                        child: Text('VERIFY & DISPATCH', style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w700)),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    codeCtrl.dispose();
    codeFocus.dispose();
  }

  InputDecoration _decoration({required String hint, bool invalid = false, String? prefixText, Widget? suffixIcon}) {
    final color = _border(invalid);
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(fontSize: 12.5.sp, color: const Color(0xFFA3A8B7)),
      prefixText: prefixText,
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: const Color(0xFFF3F5F9),
      contentPadding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(6.r), borderSide: BorderSide(color: color)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(6.r), borderSide: BorderSide(color: color)),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(6.r),
        borderSide: BorderSide(color: invalid && _submitted ? const Color(0xFFD92D20) : AppColors.primary, width: 1.2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final parcelErr = _submitted && _parcel == null;
    final modeErr = _submitted && _mode == null;
    final dateErr = _submitted && _transportDate == null;
    final expErr = _submitted && _expectedDate == null;
    final timeErr = _submitted && _dispatchTime == null;
    final nameErr = _submitted && _nameCtrl.text.trim().isEmpty;
    final phoneErr = _submitted && !_phoneValid;
    final addressErr = _submitted && _addressCtrl.text.trim().isEmpty;
    final imageErr = _submitted && _image == null;

    return Scaffold(
      backgroundColor: Colors.white,
      body: AppStatusBarWrapper(
        child: SafeArea(
          top: false,
          bottom: false,
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 22.h),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                InkWell(
                  onTap: () {
                    if (widget.onBack != null) {
                      widget.onBack!();
                    } else {
                      Navigator.of(context).maybePop();
                    }
                  },
                  child: Padding(padding: EdgeInsets.all(4.r), child: Icon(Icons.arrow_back_ios_new_rounded, size: 18.sp, color: AppColors.primary))
                ),
                SizedBox(width: 8.w),
                Text('Dispatch', style: TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w700, color: AppColors.textDark)),
              ]),
              SizedBox(height: 20.h),
              Text('Parcel No', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w700)),
              SizedBox(height: 8.h),
              Container(
                decoration: BoxDecoration(color: const Color(0xFFF3F5F9), borderRadius: BorderRadius.circular(6.r), border: Border.all(color: _border(parcelErr))),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _parcel,
                    isExpanded: true,
                    padding: EdgeInsets.symmetric(horizontal: 14.w),
                    items: _parcels.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) { if (v == null) return; setState(() { _parcel = v; _applyParcel(v); }); },
                  ),
                ),
              ),
              SizedBox(height: 10.h),
              Row(children: [
                Text('Customer Detail', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w700)),
                const Spacer(),
                InkWell(onTap: () => setState(() => _showDetails = !_showDetails), child: Icon(_showDetails ? Icons.keyboard_arrow_up_rounded : Icons.keyboard_arrow_down_rounded, color: AppColors.primary, size: 24.sp)),
              ]),
              SizedBox(height: 10.h),
              AnimatedCrossFade(
                firstChild: const SizedBox.shrink(),
                secondChild: Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(14.r),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10.r), border: Border.all(color: const Color(0xFFE4E8F1))),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _miniLabel('Customer Name'), SizedBox(height: 6.h), _valueBox(_nameCtrl.text, invalid: nameErr),
                    SizedBox(height: 12.h), _miniLabel('Phone'), SizedBox(height: 6.h), _valueBox('+91 ${_phoneCtrl.text}', invalid: phoneErr),
                    SizedBox(height: 12.h), _miniLabel('Address'), SizedBox(height: 6.h), _valueBox(_addressCtrl.text, invalid: addressErr),
                  ]),
                ),
                crossFadeState: _showDetails ? CrossFadeState.showSecond : CrossFadeState.showFirst,
                duration: const Duration(milliseconds: 220),
              ),
              SizedBox(height: 18.h),
              Text('Mode Of Transfer', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w700)),
              SizedBox(height: 8.h),
              Container(
                decoration: BoxDecoration(color: const Color(0xFFF3F5F9), borderRadius: BorderRadius.circular(6.r), border: Border.all(color: _border(modeErr))),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _mode,
                    isExpanded: true,
                    padding: EdgeInsets.symmetric(horizontal: 12.w),
                    items: _modes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setState(() => _mode = v),
                  ),
                ),
              ),
              SizedBox(height: 18.h),
              Text('Transport Schedule', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w700)),
              SizedBox(height: 8.h),
              Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _miniLabel('Date of Transport'), SizedBox(height: 6.h), _dateBox(hint: 'Select Date', value: _transportDate, invalid: dateErr, onTap: () => _pickDate(expected: false)),
                ])),
                SizedBox(width: 12.w),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  _miniLabel('Expected Delivery'), SizedBox(height: 6.h), _dateBox(hint: 'Select Date', value: _expectedDate, invalid: expErr, onTap: () => _pickDate(expected: true)),
                ])),
              ]),
              SizedBox(height: 14.h),
              _miniLabel('Dispatch Time'), SizedBox(height: 6.h), _timeBox(invalid: timeErr),
              SizedBox(height: 18.h),
              Text('Contact Person', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w700)),
              SizedBox(height: 8.h),
              _miniLabel('Full Name'), SizedBox(height: 6.h),
              TextField(controller: _nameCtrl, onChanged: (_) => setState(() {}), decoration: _decoration(hint: 'Enter full name', invalid: nameErr), style: TextStyle(fontSize: 13.sp)),
              SizedBox(height: 12.h),
              _miniLabel('Phone'), SizedBox(height: 6.h),
              TextField(controller: _phoneCtrl, focusNode: _phoneFocus, keyboardType: TextInputType.phone, maxLength: 10, onChanged: (_) => setState(() {}), inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(10)], decoration: _decoration(hint: 'Enter phone number', prefixText: '+91  ', invalid: phoneErr), style: TextStyle(fontSize: 13.sp)),
              SizedBox(height: 12.h),
              _miniLabel('Place'), SizedBox(height: 6.h),
              TextField(controller: _addressCtrl, maxLines: 2, onChanged: (_) => setState(() {}), decoration: _decoration(hint: 'Enter delivery location', invalid: addressErr), style: TextStyle(fontSize: 13.sp)),
              SizedBox(height: 18.h),
              Text('Attachments', style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w700)),
              SizedBox(height: 8.h),
              _miniLabel('Upload Image'), SizedBox(height: 6.h),
              InkWell(
                onTap: _pickImage,
                child: Container(
                  width: double.infinity,
                  height: 118.h,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF3F5F9),
                    borderRadius: BorderRadius.circular(8.r),
                    border: Border.all(color: _border(imageErr)),
                    image: _image != null ? DecorationImage(image: FileImage(_image!), fit: BoxFit.cover) : null,
                  ),
                  child: _image == null ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(Icons.file_upload_outlined, size: 26.sp, color: const Color(0xFF67758E)),
                    SizedBox(height: 8.h),
                    Text('Click to Image', style: TextStyle(fontSize: 12.sp, color: const Color(0xFF8B95A8))),
                    SizedBox(height: 4.h),
                    Text('JPG, PNG or PDF (Max 5MB)', style: TextStyle(fontSize: 9.sp, color: const Color(0xFFA6AFC0))),
                  ]) : Align(alignment: Alignment.bottomLeft, child: Container(margin: EdgeInsets.all(10.r), padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h), decoration: BoxDecoration(color: Colors.black.withValues(alpha: 0.45), borderRadius: BorderRadius.circular(20.r)), child: Text('Image selected', style: TextStyle(fontSize: 10.sp, color: Colors.white, fontWeight: FontWeight.w600)))),
                ),
              ),
              SizedBox(height: 12.h),
              _miniLabel('Dispatch Notes'), SizedBox(height: 6.h),
              TextField(controller: _notesCtrl, maxLines: 3, decoration: _decoration(hint: 'Optional'), style: TextStyle(fontSize: 13.sp)),
              SizedBox(height: 24.h),
              SizedBox(
                width: double.infinity,
                height: 42.h,
                child: ElevatedButton(
                  onPressed: _submit,
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6.r))),
                  child: Text('Confirm Dispatch', style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w700)),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _miniLabel(String text) => Text(text, style: TextStyle(fontSize: 12.5.sp, fontWeight: FontWeight.w600, color: Colors.black87));

  Widget _valueBox(String text, {bool invalid = false}) => Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
        decoration: BoxDecoration(color: const Color(0xFFF3F5F9), borderRadius: BorderRadius.circular(6.r), border: Border.all(color: _border(invalid))),
        child: Text(text, style: TextStyle(fontSize: 12.5.sp, color: const Color(0xFF445B87), fontWeight: FontWeight.w500)),
      );

  Widget _dateBox({required String hint, required DateTime? value, required bool invalid, required VoidCallback onTap}) => InkWell(
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
          decoration: BoxDecoration(color: const Color(0xFFF3F5F9), borderRadius: BorderRadius.circular(6.r), border: Border.all(color: _border(invalid))),
          child: Row(children: [
            Expanded(child: Text(value == null ? hint : _formatDate(value), style: TextStyle(fontSize: 12.5.sp, color: value == null ? const Color(0xFFA3A8B7) : const Color(0xFF445B87)))),
            Image.asset('assets/calendar_icon.png', width: 18.w, height: 18.w, fit: BoxFit.contain),
          ]),
        ),
      );

  Widget _timeBox({required bool invalid}) => InkWell(
        onTap: _pickTime,
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
          decoration: BoxDecoration(color: const Color(0xFFF3F5F9), borderRadius: BorderRadius.circular(6.r), border: Border.all(color: _border(invalid))),
          child: Row(children: [
            Expanded(child: Text(_dispatchTime == null ? 'Select Dispatch Time' : _formatTime(_dispatchTime!), style: TextStyle(fontSize: 12.5.sp, color: _dispatchTime == null ? const Color(0xFFA3A8B7) : const Color(0xFF445B87)))),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 4.h),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8.r), border: Border.all(color: const Color(0xFFDDE3EF))),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _period,
                  isDense: true,
                  items: const [DropdownMenuItem(value: 'AM', child: Text('AM')), DropdownMenuItem(value: 'PM', child: Text('PM'))],
                  onChanged: (v) { if (v != null) setState(() => _period = v); },
                ),
              ),
            ),
          ]),
        ),
      );
}
