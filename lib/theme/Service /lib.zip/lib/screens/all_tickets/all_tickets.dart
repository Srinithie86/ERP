import 'package:flutter/material.dart';
import 'package:service_ticket/core/size_utils.dart';

import '../../Widgets/app_status_bar_wrapper.dart';
import '../../core/app_colors.dart';
import '../../data/app_data.dart';
import 'all_tickets_job_card.dart';

class AllTicketsScreen extends StatefulWidget {
  const AllTicketsScreen({super.key});

  @override
  State<AllTicketsScreen> createState() => _AllTicketsScreenState();
}

class _AllTicketsScreenState extends State<AllTicketsScreen> {
  String _selectedFilter = 'ALL';
  String _searchQuery = '';
  DateTime? _selectedDateFilter;

  String _formatDateShort(DateTime date) {
    return '${date.day}/${date.month}/${date.year.toString().substring(2)}';
  }

  String _formatTimeShort(DateTime date) {
    String period = date.hour >= 12 ? 'PM' : 'AM';
    int h = date.hour > 12 ? date.hour - 12 : (date.hour == 0 ? 12 : date.hour);
    String m = date.minute.toString().padLeft(2, '0');
    return '$h:$m $period';
  }

  String _formatDayHeader(DateTime date) {
    final now = DateTime.now();
    final difference = DateTime(date.year, date.month, date.day)
        .difference(DateTime(now.year, now.month, now.day))
        .inDays;

    if (difference == 0) return 'Today, ${_formatDateShort(date)}';
    if (difference == -1) return 'Yesterday, ${_formatDateShort(date)}';
    if (difference == 1) return 'Tomorrow, ${_formatDateShort(date)}';
    return '${date.day}/${date.month}/${date.year}';
  }

  String _mapStatusToFilter(String status) {
    switch (status) {
      case 'Pending':
        return 'RECEIVED';
      case 'Accepted':
      case 'In Progress':
        return 'ASSIGNED';
      case 'Completed':
        return 'COMPLETED';
      default:
        return 'RECEIVED';
    }
  }

  String _displayTicketNo(String value) {
    return value.replaceFirst(RegExp(r'^#?(TCK|TKT)-'), '#JOB-');
  }

  int _statusStep(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return 1;
      case 'accepted':
        return 2;
      case 'in progress':
        return 3;
      case 'completed':
        return 4;
      default:
        return 1;
    }
  }

  String _statusTitle(String status) {
    switch (status.toLowerCase()) {
      case 'pending':
        return 'Call pending';
      case 'accepted':
        return 'Assigned';
      case 'in progress':
        return 'Visit in progress';
      case 'completed':
        return 'Completed';
      default:
        return status;
    }
  }

  @override
  Widget build(BuildContext context) {
    final appData = AppData.instance;

    // Map tickets to uniform items.
    var allTickets = appData.tickets.map((t) {
      final createdAt = t['createdAt'] as DateTime;
      return {
        'id': t['id'],
        'ticketNo': _displayTicketNo('${t['id']}'),
        'name': t['user'],
        'issue': t['title'],
        'location': t['location'],
        'dateText': _formatDateShort(createdAt),
        'timeText': _formatTimeShort(createdAt),
        'createdAt': createdAt,
        'status': t['status'],
        'filterCategory': _mapStatusToFilter(t['status']),
        'product': t['device'],
        'priority': t['priority'],
        'resolutionNote': t['resolutionNote'],
        'hasAudio': t['hasAudio'] ?? false,
      };
    }).toList();

    // Sort descending by date
    allTickets.sort((a, b) =>
        (b['createdAt'] as DateTime).compareTo(a['createdAt'] as DateTime));

    // Filter logic
    var displayedTickets = allTickets.where((t) {
      final matchesSearch = _searchQuery.isEmpty ||
          '${t['ticketNo']}'.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          '${t['name']}'.toLowerCase().contains(_searchQuery.toLowerCase());

      final matchesFilter = _selectedFilter == 'ALL' ||
          t['filterCategory'] == _selectedFilter;

      bool matchesDate = true;
      if (_selectedDateFilter != null) {
        final ticketDate = t['createdAt'] as DateTime;
        matchesDate = ticketDate.year == _selectedDateFilter!.year &&
            ticketDate.month == _selectedDateFilter!.month &&
            ticketDate.day == _selectedDateFilter!.day;
      }

      return matchesSearch && matchesFilter && matchesDate;
    }).toList();

    // Calculate counts
    int countAll = allTickets.length;
    int countReceived = allTickets.where((t) => t['filterCategory'] == 'RECEIVED').length;
    int countAssigned = allTickets.where((t) => t['filterCategory'] == 'ASSIGNED').length;
    int countCompleted = allTickets.where((t) => t['filterCategory'] == 'COMPLETED').length;

    // Grouping logic for day-wise view
    Map<String, List<Map<String, dynamic>>> groupedTickets = {};
    for (var ticket in displayedTickets) {
      DateTime dt = ticket['createdAt'] as DateTime;
      String dayKey = _formatDayHeader(dt);
      if (!groupedTickets.containsKey(dayKey)) groupedTickets[dayKey] = [];
      groupedTickets[dayKey]!.add(ticket);
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: AppStatusBarWrapper(
        child: SafeArea(
          top: false,
          bottom: false,
          child: Column(
            children: [
              // Top Bar
              Container(
                width: double.infinity,
                color: Colors.white,
                padding: EdgeInsets.fromLTRB(14.w, 10.h, 14.w, 16.h),
                child: Row(
                  children: [
                    InkWell(
                      onTap: () => Navigator.pop(context),
                      borderRadius: BorderRadius.circular(20.r),
                      child: Padding(
                        padding: EdgeInsets.all(4.r),
                        child: Icon(Icons.arrow_back_ios_new_rounded,
                            size: 18.sp, color: AppColors.primary),
                      ),
                    ),
                    SizedBox(width: 10.w),
                    Text(
                      'All Tickets',
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textDark,
                      ),
                    ),
                  ],
                ),
              ),

              // Search Bar
              Padding(
                padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 14.h),
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF1F4F9),
                    borderRadius: BorderRadius.circular(10.r),
                  ),
                  child: TextField(
                    onChanged: (val) => setState(() => _searchQuery = val),
                    onSubmitted: (val) {
                      setState(() => _searchQuery = val);
                      FocusScope.of(context).unfocus();
                    },
                    decoration: InputDecoration(
                      hintText: 'Search Ticket , Customer.',
                      hintStyle: TextStyle(
                          fontSize: 14.sp, color: const Color(0xFF9E9E9E)),
                      prefixIcon: Icon(Icons.search,
                          color: const Color(0xFF9E9E9E), size: 22.sp),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.tune, color: _selectedDateFilter != null ? AppColors.primary : const Color(0xFF9E9E9E)),
                        onPressed: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: _selectedDateFilter ?? DateTime.now(),
                            firstDate: DateTime(2020),
                            lastDate: DateTime(2030),
                            builder: (context, child) {
                              return Theme(
                                data: Theme.of(context).copyWith(
                                  colorScheme: ColorScheme.light(
                                    primary: AppColors.primary,
                                  ),
                                ),
                                child: child!,
                              );
                            },
                          );
                          setState(() => _selectedDateFilter = date);
                        },
                      ),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 12.h),
                    ),
                  ),
                ),
              ),

              // Filter Chips
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.only(left: 16.w, bottom: 20.h),
                child: Row(
                  children: [
                    _FilterChip(
                      label: 'ALL($countAll)',
                      selected: _selectedFilter == 'ALL',
                      onTap: () => setState(() => _selectedFilter = 'ALL'),
                    ),
                    SizedBox(width: 10.w),
                    _FilterChip(
                      label: 'RECEIVED ($countReceived)',
                      selected: _selectedFilter == 'RECEIVED',
                      onTap: () => setState(() => _selectedFilter = 'RECEIVED'),
                    ),
                    SizedBox(width: 10.w),
                    _FilterChip(
                      label: 'ASSIGNED ($countAssigned)',
                      selected: _selectedFilter == 'ASSIGNED',
                      onTap: () => setState(() => _selectedFilter = 'ASSIGNED'),
                    ),
                    SizedBox(width: 10.w),
                    _FilterChip(
                      label: 'COMPLETED ($countCompleted)',
                      selected: _selectedFilter == 'COMPLETED',
                      onTap: () => setState(() => _selectedFilter = 'COMPLETED'),
                    ),
                  ],
                ),
              ),

              // List Area
              Expanded(
                child: groupedTickets.isEmpty
                    ? Center(
                        child: Text(
                        'No tickets found.',
                        style: TextStyle(
                            fontSize: 14.sp, color: const Color(0xFF9E9E9E)),
                      ))
                    : ListView.builder(
                        padding: EdgeInsets.symmetric(horizontal: 16.w),
                        itemCount: groupedTickets.length,
                        itemBuilder: (context, index) {
                          String dayKey = groupedTickets.keys.elementAt(index);
                          List<Map<String, dynamic>> dayTickets =
                              groupedTickets[dayKey]!;

                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: EdgeInsets.symmetric(vertical: 10.h),
                                child: Text(
                                  dayKey,
                                  style: TextStyle(
                                    fontSize: 13.sp,
                                    fontWeight: FontWeight.w600,
                                    color: const Color(0xFF445B87),
                                  ),
                                ),
                              ),
                               ...dayTickets.asMap().entries.map(
                                (entry) {
                                  final t = entry.value;
                                  // Determine appropriate label depending on category
                                  String label = t['status'] == 'Pending'
                                      ? 'Received'
                                      : t['status'] == 'Completed'
                                          ? 'Completed'
                                          : 'Assigned';

                                  return AllTicketsJobCard(
                                    ticketNo: t['ticketNo'],
                                    name: t['name'],
                                    issue: t['issue'],
                                    dateText: t['dateText'],
                                    timeText: t['timeText'],
                                    label: label,
                                    filterCategory: t['filterCategory'],
                                    address: t['location'],
                                    product: t['product'] ?? '',
                                    phone: '+91 98765 43210',
                                    complaint: 'User reports ${t['issue']} with ${t['product']}',
                                    showComplaintAudio: t['hasAudio'] == true,
                                    resolutionNote: t['resolutionNote'],
                                    onAssignTap: () => _openAssignBottomSheet(
                                        context, t, appData),
                                    onViewStatusTap: () => _openStatusDialog(context, t),
                                    onCloseWithReason: (reason) {
                                      setState(() {
                                        appData.updateTicket(
                                          t['id'],
                                          status: 'Completed',
                                          resolutionNote: reason,
                                        );
                                      });
                                    },
                                  );
                                },
                              ),
                            ],
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _openAssignBottomSheet(
      BuildContext context, Map<String, dynamic> ticketData, AppData appData) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (BuildContext sheetContext) {
        return _AssignBottomSheet(
          ticketData: ticketData,
          onAssign: (String priority, String engineer) {
            setState(() {
              appData.updateTicket(
                ticketData['id'],
                status: 'Accepted',
                priority: priority,
                assignedTo: engineer,
              );
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Assigned to $engineer successfully')),
            );
          },
        );
      },
    );
  }

  void _openStatusDialog(BuildContext context, Map<String, dynamic> ticketData) {
    final status = '${ticketData['status'] ?? ''}';
    final currentStep = _statusStep(status);
    final ticketNo = '${ticketData['ticketNo'] ?? ''}';
    final name = '${ticketData['name'] ?? ''}';
    final issue = '${ticketData['issue'] ?? ''}';
    final location = '${ticketData['location'] ?? ''}';
    final dateText = '${ticketData['dateText'] ?? ''}';
    final timeText = '${ticketData['timeText'] ?? ''}';
    final priority = '${ticketData['priority'] ?? ''}';
    final product = '${ticketData['product'] ?? ''}';
    final statusLabel = _statusTitle(status);

    showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (dialogContext) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: 18.w, vertical: 24.h),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18.r)),
          child: Padding(
            padding: EdgeInsets.fromLTRB(16.w, 16.h, 16.w, 18.h),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Status Tracking',
                          style: TextStyle(
                            fontSize: 17.sp,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textDark,
                          ),
                        ),
                      ),
                      InkWell(
                        onTap: () => Navigator.of(dialogContext).pop(),
                        borderRadius: BorderRadius.circular(20.r),
                        child: Padding(
                          padding: EdgeInsets.all(4.r),
                          child: Icon(
                            Icons.close_rounded,
                            size: 20.sp,
                            color: const Color(0xFF667085),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 14.h),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(14.r),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF5F8FF),
                      borderRadius: BorderRadius.circular(14.r),
                      border: Border.all(color: const Color(0xFFD9E2FF)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                ticketNo,
                                style: TextStyle(
                                  fontSize: 14.sp,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.primary,
                                ),
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 5.h),
                              decoration: BoxDecoration(
                                color: const Color(0xFFE7F0FF),
                                borderRadius: BorderRadius.circular(999.r),
                              ),
                              child: Text(
                                statusLabel,
                                style: TextStyle(
                                  fontSize: 11.sp,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.primary,
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10.h),
                        Text(
                          name,
                          style: TextStyle(
                            fontSize: 16.sp,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textDark,
                          ),
                        ),
                        SizedBox(height: 4.h),
                        Text(
                          issue,
                          style: TextStyle(
                            fontSize: 12.5.sp,
                            fontWeight: FontWeight.w500,
                            color: const Color(0xFF445B87),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        Text(
                          '$product - $priority',
                          style: TextStyle(
                            fontSize: 11.5.sp,
                            color: const Color(0xFF667085),
                            height: 1.3,
                          ),
                        ),
                        SizedBox(height: 3.h),
                        Text(
                          '$location - $dateText - $timeText',
                          style: TextStyle(
                            fontSize: 11.5.sp,
                            color: const Color(0xFF667085),
                            height: 1.3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 18.h),
                  Text(
                    'Tracking',
                    style: TextStyle(
                      fontSize: 15.sp,
                      fontWeight: FontWeight.w700,
                      color: AppColors.textDark,
                    ),
                  ),
                  SizedBox(height: 12.h),
                  _TicketTrackingBar(currentStep: currentStep),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _FilterChip extends StatelessWidget {
  const _FilterChip({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14.r),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 18.w, vertical: 11.h),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF2F4FB4) : const Color(0xFF9EB5FF),
          borderRadius: BorderRadius.circular(16.r),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13.sp,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

class _AssignBottomSheet extends StatefulWidget {
  const _AssignBottomSheet({
    required this.ticketData,
    required this.onAssign,
  });

  final Map<String, dynamic> ticketData;
  final void Function(String priority, String engineer) onAssign;

  @override
  State<_AssignBottomSheet> createState() => _AssignBottomSheetState();
}

class _AssignBottomSheetState extends State<_AssignBottomSheet> {
  final List<String> priorities = ['Low', 'Medium', 'High', 'Urgent'];
  final List<String> engineers = ['Thanu', 'Rajesh', 'Sowmiya', 'Arjun', 'Tamilarasi'];
  
  String? _selectedPriority;
  String? _selectedEngineer;
  bool _submitted = false;

  @override
  void initState() {
    super.initState();
    String p = widget.ticketData['priority'] ?? 'Low';
    if (priorities.contains(p)) {
      _selectedPriority = p;
    }
  }

  bool _isDropdownError(String? value) => _submitted && (value == null || value.isEmpty);

  void _handleSubmit() {
    setState(() => _submitted = true);

    if (_selectedPriority == null || _selectedEngineer == null) {
      return;
    }

    widget.onAssign(_selectedPriority!, _selectedEngineer!);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    return Container(
      padding: EdgeInsets.only(bottom: bottomInset),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20.r)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle bar
          Center(
            child: Container(
              margin: EdgeInsets.only(top: 12.h),
              width: 40.w,
              height: 4.h,
              decoration: BoxDecoration(
                color: const Color(0xFFD1D5DB),
                borderRadius: BorderRadius.circular(2.r),
              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.fromLTRB(20.w, 10.h, 20.w, 10.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Assign Ticket',
                  style: TextStyle(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textDark,
                  ),
                ),
                InkWell(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    padding: EdgeInsets.all(4.r),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF3F4F6),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(Icons.close_rounded, size: 20.sp, color: const Color(0xFF6B7280)),
                  ),
                )
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(20.w, 10.h, 20.w, 24.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildLabel('Ticket No', false),
                          SizedBox(height: 6.h),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: const Color(0xFFF9FAFB),
                              borderRadius: BorderRadius.circular(8.r),
                              border: Border.all(color: const Color(0xFFE5E7EB)),
                            ),
                            child: Text(
                              widget.ticketData['ticketNo'],
                              style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 16.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _buildLabel('Customer Name', false),
                          SizedBox(height: 6.h),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: const Color(0xFFF9FAFB),
                              borderRadius: BorderRadius.circular(8.r),
                              border: Border.all(color: const Color(0xFFE5E7EB)),
                            ),
                            child: Text(
                              widget.ticketData['name'],
                              style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 16.h),

                _buildLabel('Priority Type', true),
                SizedBox(height: 6.h),
                _buildDropdown(
                  value: _selectedPriority,
                  hint: 'Select Priority',
                  items: priorities,
                  hasError: _isDropdownError(_selectedPriority),
                  onChanged: (val) => setState(() => _selectedPriority = val),
                ),
                SizedBox(height: 16.h),

                _buildLabel('Service Engineer', true),
                SizedBox(height: 6.h),
                _buildDropdown(
                  value: _selectedEngineer,
                  hint: 'Select Engineer',
                  items: engineers,
                  hasError: _isDropdownError(_selectedEngineer),
                  onChanged: (val) => setState(() => _selectedEngineer = val),
                ),
                SizedBox(height: 32.h),

                SizedBox(
                  width: double.infinity,
                  height: 48.h,
                  child: ElevatedButton(
                    onPressed: _handleSubmit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      elevation: 0,
                    ),
                    child: Text(
                      'Assign Ticket',
                      style: TextStyle(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLabel(String text, bool isMandatory) {
    return RichText(
      text: TextSpan(
        text: text,
        style: TextStyle(
          fontSize: 13.sp,
          fontWeight: FontWeight.w600,
          color: Colors.black87,
        ),
        children: isMandatory
            ? [TextSpan(text: ' *', style: TextStyle(color: Colors.red, fontSize: 13.sp))]
            : [],
      ),
    );
  }

  Widget _buildDropdown({
    required String? value,
    required String hint,
    required List<String> items,
    required bool hasError,
    required ValueChanged<String?> onChanged,
  }) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(horizontal: 14.w),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(8.r),
        border: Border.all(
          color: hasError ? Colors.red : const Color(0xFFE5E7EB),
        ),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          hint: Text(hint, style: TextStyle(fontSize: 14.sp, color: const Color(0xFF9CA3AF))),
          isExpanded: true,
          icon: Icon(Icons.keyboard_arrow_down_rounded, color: const Color(0xFF6B7280)),
          items: items
              .map(
                (item) => DropdownMenuItem(
                  value: item,
                  child: Text(item, style: TextStyle(fontSize: 14.sp)),
                ),
              )
              .toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}

class _TicketTrackingBar extends StatelessWidget {
  const _TicketTrackingBar({
    required this.currentStep,
  });

  final int currentStep;

  static const _steps = [
    ('Call', Icons.call_rounded),
    ('Assigned', Icons.assignment_turned_in_rounded),
    ('Visit', Icons.location_on_rounded),
    ('Completed', Icons.check_circle_rounded),
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: List.generate(_steps.length, (index) {
        final stepNumber = index + 1;
        final isDone = stepNumber < currentStep;
        final isCurrent = stepNumber == currentStep;
        final isPending = stepNumber > currentStep;

        final Color activeColor = isDone
            ? const Color(0xFF2FB344)
            : isCurrent
                ? AppColors.primary
                : const Color(0xFFD0D7E2);
        final Color textColor = isPending ? const Color(0xFF8A94A6) : AppColors.textDark;

        return Expanded(
          child: Column(
            children: [
              Row(
                children: [
                  if (index > 0)
                    Expanded(
                      child: Container(
                        height: 4.h,
                        color: stepNumber <= currentStep ? const Color(0xFF2FB344) : const Color(0xFFD9E1EC),
                      ),
                    ),
                  Container(
                    width: 28.w,
                    height: 28.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: activeColor,
                    ),
                    alignment: Alignment.center,
                    child: isDone
                        ? Icon(Icons.check_rounded, size: 16.sp, color: Colors.white)
                        : Text(
                            '$stepNumber',
                            style: TextStyle(
                              fontSize: 11.sp,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                  ),
                  if (index < _steps.length - 1)
                    Expanded(
                      child: Container(
                        height: 4.h,
                        color: stepNumber < currentStep ? const Color(0xFF2FB344) : const Color(0xFFD9E1EC),
                      ),
                    ),
                ],
              ),
              SizedBox(height: 8.h),
              Text(
                _steps[index].$1,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 11.sp,
                  fontWeight: isCurrent ? FontWeight.w700 : FontWeight.w600,
                  color: textColor,
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
