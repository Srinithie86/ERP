import 'package:flutter/material.dart';
import 'package:service_ticket/core/size_utils.dart';

import '../Widgets/common_job_card.dart';
import '../core/app_colors.dart';
import '../data/app_data.dart';
import 'Support/notification_screen.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({
    super.key,
    required this.onOpenTasks,
    required this.onOpenDirectVisit,
  });

  final VoidCallback onOpenTasks;
  final ValueChanged<Map<String, dynamic>> onOpenDirectVisit;

  String _formatDate(DateTime date) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  String _formatDateShort(DateTime date) {
    return '${date.day}/${date.month}/${date.year.toString().substring(2)}';
  }

  String _formatTimeShort(DateTime date) {
    final period = date.hour >= 12 ? 'PM' : 'AM';
    final hour = date.hour > 12 ? date.hour - 12 : (date.hour == 0 ? 12 : date.hour);
    final minute = date.minute.toString().padLeft(2, '0');
    return '$hour:$minute $period';
  }

  String _displayTicketNo(String value) {
    return value.replaceFirst(RegExp(r'^#?(TCK|TKT)-'), '#JOB-');
  }

  Map<String, double> _jobCoordinatesForLocation(String location) {
    final normalized = location.toLowerCase();
    if (normalized.contains('finance')) {
      return {'lat': 11.0169, 'lng': 76.9561};
    }
    if (normalized.contains('hr')) {
      return {'lat': 11.0172, 'lng': 76.9555};
    }
    if (normalized.contains('admin')) {
      return {'lat': 11.0175, 'lng': 76.9564};
    }
    if (normalized.contains('floor 1')) {
      return {'lat': 11.0178, 'lng': 76.9552};
    }
    return {'lat': 11.0168, 'lng': 76.9558};
  }

  Map<String, dynamic> _buildDirectVisitJob(
    Map<String, dynamic> ticket,
    Map<String, dynamic> profile,
  ) {
    final createdAt = ticket['createdAt'] as DateTime? ?? DateTime.now();
    final ticketId = '${ticket['id'] ?? ticket['ticketId'] ?? ''}';
    final location = '${ticket['location'] ?? ticket['address'] ?? ''}';
    final coords = _jobCoordinatesForLocation(location);

    return {
      'ticketNo': ticketId.startsWith('TCK') ? _displayTicketNo('#$ticketId') : ticketId,
      'ticketId': ticketId,
      'name': '${ticket['user'] ?? profile['name'] ?? ''}',
      'customerName': '${ticket['user'] ?? profile['name'] ?? ''}',
      'issue': '${ticket['title'] ?? ticket['issue'] ?? ''}',
      'scheduledAt': createdAt,
      'dateText': _formatDateShort(createdAt),
      'timeText': _formatTimeShort(createdAt),
      'label': '${ticket['status']}' == 'Completed' ? 'Completed' : 'Today',
      'product': '${ticket['device'] ?? ''}',
      'complaint': '${ticket['title'] ?? ticket['issue'] ?? ''}',
      'phone': '${profile['phone'] ?? ticket['phone'] ?? ''}',
      'address': location,
      'locationLabel': location,
      'priority': '${ticket['priority'] ?? ''}',
      'jobLatitude': coords['lat'],
      'jobLongitude': coords['lng'],
      'showAudio': ticket['hasAudio'] == true,
      'audioUrl': ticket['audioUrl'],
      'complaintTranslation': '${ticket['title'] ?? ticket['issue'] ?? ''}',
    };
  }

  @override
  Widget build(BuildContext context) {
    final topInset = MediaQuery.of(context).padding.top;
    final appData = AppData.instance;
    final profile = appData.profile;
    final today = DateTime.now();

    final assignedCards = appData.tickets
        .where((ticket) {
          final status = '${ticket['status']}'.toLowerCase();
          return status == 'pending' || status == 'accepted' || status == 'in progress';
        })
        .toList()
      ..sort((a, b) {
        final aDate = a['createdAt'] as DateTime? ?? today;
        final bDate = b['createdAt'] as DateTime? ?? today;
        return bDate.compareTo(aDate);
      });

    final pendingJobCount = appData.pendingCount;
    final urgentJobCount = appData.tickets.where((ticket) {
      final priority = '${ticket['priority']}'.toLowerCase();
      return priority == 'urgent';
    }).length;

    final displayedTasks = assignedCards.take(3).toList();
    final spareItems = appData.parts.take(2).toList();

    return Column(
      children: [
        Container(
          width: double.infinity,
          color: AppColors.primary,
          padding: EdgeInsets.fromLTRB(16.w, topInset + 10.h, 16.w, 18.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Builder(
                    builder: (context) => InkWell(
                      onTap: () => Scaffold.of(context).openDrawer(),
                      child: Icon(
                        Icons.menu_rounded,
                        color: Colors.white,
                        size: 28.sp,
                      ),
                    ),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const NotificationScreen(),
                      ),
                    ),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        Icon(
                          Icons.notifications_rounded,
                          color: Colors.white,
                          size: 28.sp,
                        ),
                        Positioned(
                          right: 1.w,
                          top: 1.h,
                          child: Container(
                            width: 9.w,
                            height: 9.w,
                            decoration: const BoxDecoration(
                              color: Color(0xFFE53935),
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: 14.h),
              Text(
                'Good Morning ${profile['name']}!',
                style: TextStyle(
                  fontSize: 20.sp,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                ),
              ),
              SizedBox(height: 6.h),
              Text(
                _formatDate(today),
                style: TextStyle(
                  fontSize: 12.sp,
                  color: Colors.white.withValues(alpha: 0.85),
                ),
              ),
              SizedBox(height: 18.h),
              Row(
                children: [
                  Expanded(
                    child: _StatCard(
                      count: '${assignedCards.length}',
                      label: "Today's Task",
                      color: const Color(0xFF4CAF50),
                      onTap: onOpenTasks,
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: _StatCard(
                      count: '$pendingJobCount',
                      label: 'Pending Job',
                      color: const Color(0xFFFDD835),
                      darkText: true,
                      onTap: onOpenTasks,
                    ),
                  ),
                  SizedBox(width: 8.w),
                  Expanded(
                    child: _StatCard(
                      count: '$urgentJobCount',
                      label: 'Urgent',
                      color: const Color(0xFFE53935),
                      onTap: onOpenTasks,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: Container(
            color: Colors.white,
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(16.w, 20.h, 16.w, 24.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const _SectionHeader(title: "Today's Task"),
                      InkWell(
                        onTap: onOpenTasks,
                        child: Text(
                          'View more',
                          style: TextStyle(
                            fontSize: 12.sp,
                            color: const Color(0xFF667085),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 14.h),
                  if (displayedTasks.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(16.r),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.circular(12.r),
                      ),
                      child: Text(
                        'No assigned tasks for today.',
                        style: TextStyle(
                          fontSize: 13.sp,
                          color: const Color(0xFF667085),
                        ),
                      ),
                    )
                  else
                    ...displayedTasks.map((ticket) {
                      final ticketId = '${ticket['id']}';
                      final createdAt = ticket['createdAt'] as DateTime? ?? today;
                      final directVisitJob = _buildDirectVisitJob(ticket, profile);
                      return CommonJobCard(
                        ticketNo: ticketId.startsWith('TCK') ? '#JOB-${ticketId.split('-').last}' : ticketId,
                        name: '${ticket['user'] ?? profile['name']}',
                        issue: '${ticket['title'] ?? ''}',
                        dateText: _formatDateShort(createdAt),
                        timeText: _formatTimeShort(createdAt),
                        label: '${ticket['status']}' == 'Completed' ? 'Completed' : 'Today',
                        product: '${ticket['device'] ?? ''}',
                        complaint: '${ticket['title'] ?? ''}',
                        phone: '${profile['phone']}',
                        address: '${ticket['location'] ?? ''}',
                        showComplaintAudio: ticket['hasAudio'] == true,
                        audioUrl: ticket['audioUrl'],
                        complaintTranslation: '${ticket['title'] ?? ''}',
                        priority: '${ticket['priority'] ?? ''}',
                        primaryActionLabel: 'Direct Visit',
                        onPrimaryTap: () => onOpenDirectVisit(directVisitJob),
                      );
                    }),
                  SizedBox(height: 24.h),
                  const _SectionHeader(title: 'Spares'),
                  SizedBox(height: 14.h),
                  ...spareItems.map((part) => _SpareCard(
                        name: '${part['name']}',
                        code: '${part['id']}',
                        quantity: '${part['stock']}',
                        receivedDate: _formatDate(today),
                        remarks: 'Available in inventory',
                      )),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.count,
    required this.label,
    required this.color,
    this.darkText = false,
    this.onTap,
  });

  final String count;
  final String label;
  final Color color;
  final bool darkText;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8.r),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(8.r),
        ),
        child: Column(
          children: [
            Text(
              count,
              style: TextStyle(
                fontSize: 24.sp,
                fontWeight: FontWeight.w700,
                color: darkText ? Colors.black87 : Colors.white,
              ),
            ),
            SizedBox(height: 2.h),
            Text(
              label,
              style: TextStyle(
                fontSize: 11.sp,
                fontWeight: FontWeight.w600,
                color: darkText ? Colors.black87 : Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4.w,
          height: 18.h,
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(4.r),
          ),
        ),
        SizedBox(width: 8.w),
        Text(
          title,
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w700,
            color: Colors.black,
          ),
        ),
      ],
    );
  }
}


class _SpareCard extends StatelessWidget {
  const _SpareCard({
    required this.name,
    required this.code,
    required this.quantity,
    required this.receivedDate,
    required this.remarks,
  });

  final String name;
  final String code;
  final String quantity;
  final String receivedDate;
  final String remarks;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFF9155FD)),
        borderRadius: BorderRadius.circular(6.r),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(8.w),
            color: const Color(0xFF9155FD),
            child: Row(
              children: [
                Container(
                  padding: EdgeInsets.all(6.r),
                  decoration: const BoxDecoration(
                    color: Color(0xFF322748),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.build_rounded,
                    color: Colors.white,
                    size: 18.sp,
                  ),
                ),
                SizedBox(width: 10.w),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: TextStyle(
                        fontSize: 15.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      'Code: $code',
                      style: TextStyle(fontSize: 12.sp, color: Colors.white),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
            child: Row(
              children: [
                Expanded(
                  child: Row(
                    children: [
                      Image.asset(
                        'assets/quantity_icon.png',
                        width: 22.w,
                        height: 22.h,
                      ),
                      SizedBox(width: 6.w),
                      Text(
                        'Quantity: $quantity',
                        style: TextStyle(fontSize: 12.sp),
                      ),
                    ],
                  ),
                ),
                Container(width: 1, height: 24.h, color: Colors.grey.shade300),
                Expanded(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        'assets/calendar_icon.png',
                        width: 22.w,
                        height: 22.h,
                      ),
                      SizedBox(width: 6.w),
                      Text(
                        'Received: $receivedDate',
                        style: TextStyle(fontSize: 12.sp),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1),
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 8.h),
            color: const Color(0xFFFFF8F8),
            child: Text(
              'Remarks : $remarks',
              style: TextStyle(fontSize: 11.sp, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}
