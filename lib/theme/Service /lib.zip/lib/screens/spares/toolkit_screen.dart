import 'package:flutter/material.dart';
import 'package:service_ticket/core/size_utils.dart';

import '../../Widgets/app_status_bar_wrapper.dart';
import '../../core/app_colors.dart';

class ToolkitScreen extends StatelessWidget {
  const ToolkitScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Data tailored for future API integration
    final tools = [
      {'sno': 1, 'name': 'Insulated\nScrewdriver Set', 'code': 'TLK-001', 'qty': '1 Set'},
      {'sno': 2, 'name': 'Combination Pliers', 'code': 'TLK-002', 'qty': '2 Set'},
      {'sno': 3, 'name': 'Wire Stripper', 'code': 'TLK-003', 'qty': '2 Set'},
      {'sno': 4, 'name': 'Voltage Tester', 'code': 'TLK-004', 'qty': '1 Set'},
    ];

    const String verifiedDate = '9/10/26';

    final Color headerBg = AppColors.primary;
    const Color borderColor = Color(0xFF3D5EC7);

    return Scaffold(
      backgroundColor: Colors.white,
      body: AppStatusBarWrapper(
        child: SafeArea(
          top: false,
          bottom: false,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ─── Header ───
              Padding(
                padding: EdgeInsets.fromLTRB(14.w, 12.h, 14.w, 0),
                child: Row(
                  children: [
                    InkWell(
                      onTap: () => Navigator.of(context).maybePop(),
                      borderRadius: BorderRadius.circular(20.r),
                      child: Padding(
                        padding: EdgeInsets.all(4.r),
                        child: Icon(
                          Icons.arrow_back,
                          size: 22.sp,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                    SizedBox(width: 10.w),
                    Text(
                      'My Toolkit',
                      style: TextStyle(
                        fontSize: 20.sp,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textDark,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 24.h),

              // ─── Table ───
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: borderColor, width: 1.5),
                    borderRadius: BorderRadius.circular(6.r),
                  ),
                  child: Column(
                    children: [
                      // Table Header
                      Container(
                        decoration: BoxDecoration(
                          color: headerBg,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(4.5.r),
                            topRight: Radius.circular(4.5.r),
                          ),
                        ),
                        child: Row(
                          children: [
                            _HeaderCell(text: 'S.No', flex: 1),
                            _HeaderCell(text: 'Name', flex: 3),
                            _HeaderCell(text: 'Tool Code', flex: 3),
                            _HeaderCell(text: 'Qt', flex: 2),
                          ],
                        ),
                      ),

                      // Table Rows
                      ...tools.map((tool) {
                        final isLast = tool == tools.last;
                        return Container(
                          decoration: BoxDecoration(
                            border: isLast
                                ? null
                                : Border(
                                    bottom: BorderSide(
                                      color: borderColor.withValues(alpha: 0.3),
                                      width: 1,
                                    ),
                                  ),
                          ),
                          child: IntrinsicHeight(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                _DataCell(
                                  text: '${tool['sno']}',
                                  flex: 1,
                                  isBold: false,
                                  borderColor: borderColor,
                                ),
                                _DataCell(
                                  text: '${tool['name']}',
                                  flex: 3,
                                  isBold: false,
                                  borderColor: borderColor,
                                ),
                                _DataCell(
                                  text: '${tool['code']}',
                                  flex: 3,
                                  isBold: true,
                                  textColor: AppColors.primary,
                                  borderColor: borderColor,
                                ),
                                _DataCell(
                                  text: '${tool['qty']}',
                                  flex: 2,
                                  isBold: true,
                                  borderColor: borderColor,
                                  showBorder: false,
                                ),
                              ],
                            ),
                          ),
                        );
                      }),

                      // Verified Date Footer
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 16.w),
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(4.5.r),
                            bottomRight: Radius.circular(4.5.r),
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                              'assets/verified_icon.png',
                              width: 18.w,
                              height: 18.w,
                              color: Colors.white,
                            ),
                            SizedBox(width: 8.w),
                            Text(
                              'Verified Date : $verifiedDate',
                              style: TextStyle(
                                fontSize: 14.sp,
                                fontWeight: FontWeight.w700,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────
// Header Cell
// ──────────────────────────────────────────────
class _HeaderCell extends StatelessWidget {
  const _HeaderCell({required this.text, required this.flex});

  final String text;
  final int flex;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flex,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 6.w),
        child: Center(
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 13.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}

// ──────────────────────────────────────────────
// Data Cell
// ──────────────────────────────────────────────
class _DataCell extends StatelessWidget {
  const _DataCell({
    required this.text,
    required this.flex,
    required this.borderColor,
    this.isBold = false,
    this.textColor,
    this.showBorder = true,
  });

  final String text;
  final int flex;
  final bool isBold;
  final Color? textColor;
  final Color borderColor;
  final bool showBorder;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: flex,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 14.h, horizontal: 6.w),
        decoration: showBorder
            ? BoxDecoration(
                border: Border(
                  right: BorderSide(
                    color: borderColor.withValues(alpha: 0.2),
                    width: 1,
                  ),
                ),
              )
            : null,
        child: Center(
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12.sp,
              fontWeight: isBold ? FontWeight.w700 : FontWeight.w500,
              color: textColor ?? Colors.black87,
              height: 1.3,
            ),
          ),
        ),
      ),
    );
  }
}
