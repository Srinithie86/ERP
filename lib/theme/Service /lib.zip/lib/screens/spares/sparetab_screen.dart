import 'package:flutter/material.dart';
import 'package:service_ticket/core/size_utils.dart';

import '../../Widgets/app_status_bar_wrapper.dart';
import '../../core/app_colors.dart';
import '../../data/app_data.dart';

class SparePartsTab extends StatelessWidget {
  const SparePartsTab({
    super.key,
    this.onBack,
  });

  final VoidCallback? onBack;

  @override
  Widget build(BuildContext context) {
    final appData = AppData.instance;
    final profile = appData.profile;
    final parts = appData.parts;

    final myParts = parts.take(5).toList();
    final usedParts = parts.skip(5).take(2).toList();

    return AppStatusBarWrapper(
      child: Container(
        color: Colors.white,
        child: SafeArea(
          top: false,
          bottom: false,
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(16.w, 12.h, 16.w, 20.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    InkWell(
                      onTap: onBack,
                      borderRadius: BorderRadius.circular(20.r),
                      child: Padding(
                        padding: EdgeInsets.all(4.r),
                        child: Icon(
                          Icons.arrow_back_ios_new_rounded,
                          size: 18.sp,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                    SizedBox(width: 10.w),
                    Text(
                      'Spares',
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textDark,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 18.h),
                Row(
                  children: [
                    Expanded(
                      child: _SummaryBox(
                        count: '${myParts.length}',
                        label: 'My Parts',
                        colors: const [Color(0xFF42D74D), Color(0xFF1D8E39)],
                      ),
                    ),
                    SizedBox(width: 12.w),
                    Expanded(
                      child: _SummaryBox(
                        count: '${usedParts.length}',
                        label: 'Used Parts',
                        colors: const [Color(0xFFF4A33C), Color(0xFFAC6A28)],
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 18.h),
                Text(
                  'My Parts',
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(height: 12.h),
                ...myParts.map(
                  (part) => Padding(
                    padding: EdgeInsets.only(bottom: 12.h),
                    child: _MyPartCard(part: part),
                  ),
                ),
                SizedBox(height: 12.h),
                Text(
                  'Used Parts',
                  style: TextStyle(
                    fontSize: 15.sp,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
                SizedBox(height: 12.h),
                ...usedParts.map(
                  (part) => Padding(
                    padding: EdgeInsets.only(bottom: 12.h),
                    child: _UsedPartCard(
                      part: part,
                      technicianName: '${profile['name']}',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SummaryBox extends StatelessWidget {
  const _SummaryBox({
    required this.count,
    required this.label,
    required this.colors,
  });

  final String count;
  final String label;
  final List<Color> colors;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 86.h,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(12.r),
        boxShadow: [
          BoxShadow(
            color: colors.last.withValues(alpha: 0.24),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            count,
            style: TextStyle(
              fontSize: 26.sp,
              fontWeight: FontWeight.w700,
              color: Colors.white,
              height: 1,
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            label,
            style: TextStyle(
              fontSize: 14.5.sp,
              fontWeight: FontWeight.w600,
              color: Colors.white,
              height: 1,
            ),
          ),
        ],
      ),
    );
  }
}

class _MyPartCard extends StatelessWidget {
  const _MyPartCard({required this.part});

  final Map<String, dynamic> part;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        border: Border.all(color: const Color(0xFFD38BFF)),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
            decoration: BoxDecoration(
              color: const Color(0xFF8854D0),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(14.r),
                topRight: Radius.circular(14.r),
              ),
            ),
            child: Row(
              children: [
                const _CircleIcon(
                  icon: Icons.build_rounded,
                  color: Color(0xFF4B197E),
                ),
                SizedBox(width: 8.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _displayName(part),
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        'Code: ${part['id']}',
                        style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.white.withValues(alpha: 0.9),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            color: const Color(0xFFFFF1F1),
            padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 10.h),
            child: Row(
              children: [
                Image.asset('assets/quantity_icon.png', width: 18.w, height: 18.h),
                SizedBox(width: 4.w),
                Expanded(
                  child: Text(
                    'Quantity: ${part['stock']}',
                    style: TextStyle(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w500,
                      color: Colors.black87,
                    ),
                  ),
                ),
                Image.asset('assets/calendar_icon.png', width: 18.w, height: 18.h),
                SizedBox(width: 4.w),
                Expanded(
                  child: Text(
                    'Received: 06 Apr 2026',
                    style: TextStyle(
                      fontSize: 11.sp,
                      fontWeight: FontWeight.w500,
                      color: Colors.black87,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0xFFD38BFF)),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 10.h),
            child: Align(
              alignment: Alignment.center,
              child: Text(
                'Remarks : ${_remarksFor(part)}',
                style: TextStyle(
                  fontSize: 11.sp,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _UsedPartCard extends StatelessWidget {
  const _UsedPartCard({
    required this.part,
    required this.technicianName,
  });

  final Map<String, dynamic> part;
  final String technicianName;

  @override
  Widget build(BuildContext context) {
    final issue = _issueFor(part);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14.r),
        border: Border.all(color: const Color(0xFF84B7EF)),
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
            decoration: BoxDecoration(
              color: const Color(0xFF3451B2),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(14.r),
                topRight: Radius.circular(14.r),
              ),
            ),
            child: Row(
              children: [
                const _CircleIcon(
                  icon: Icons.build_circle_rounded,
                  color: Color(0xFF0D4E96),
                ),
                SizedBox(width: 8.w),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _displayName(part),
                        style: TextStyle(
                          fontSize: 16.sp,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        'Code: ${part['id']}',
                        style: TextStyle(
                          fontSize: 12.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.white.withValues(alpha: 0.9),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            color: const Color(0xFFFFF1F1),
            padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 10.h),
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.person_rounded,
                        size: 16.sp, color: const Color(0xFF5D758C)),
                    SizedBox(width: 4.w),
                    Expanded(
                      child: Text(
                        technicianName,
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                    Image.asset('assets/calendar_icon.png',
                        width: 16.sp, height: 16.sp),
                    SizedBox(width: 4.w),
                    Expanded(
                      child: Text(
                        'Used Date: 07 Apr 2026',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8.h),
                const Divider(height: 1, color: Color(0xFFB7C3DA)),
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Icon(Icons.report_problem_rounded,
                        size: 16.sp, color: const Color(0xFFE9B217)),
                    SizedBox(width: 4.w),
                    Expanded(
                      child: Text(
                        'Problem: $issue',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8.h),
                const Divider(height: 1, color: Color(0xFFB7C3DA)),
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Icon(Icons.inventory_2_rounded,
                        size: 16.sp, color: const Color(0xFFCF7A1B)),
                    SizedBox(width: 4.w),
                    Expanded(
                      child: Text(
                        'Used Quantity: ${_usedQuantityFor(part)}',
                        style: TextStyle(
                          fontSize: 11.sp,
                          fontWeight: FontWeight.w500,
                          color: Colors.black87,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CircleIcon extends StatelessWidget {
  const _CircleIcon({
    required this.icon,
    required this.color,
  });

  final IconData icon;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 28.w,
      height: 28.w,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.08),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Icon(icon, size: 17.sp, color: color),
    );
  }
}

String _displayName(Map<String, dynamic> part) {
  final name = '${part['name']}';
  if (name.length <= 22) return name;
  return '${name.substring(0, 22)}...';
}

String _remarksFor(Map<String, dynamic> part) {
  final stock = part['stock'] as int;
  if (stock <= 1) {
    return 'low stock, request replenishment';
  }
  return 'new stock added to inventory';
}

String _issueFor(Map<String, dynamic> part) {
  final category = '${part['category']}';
  return switch (category) {
    'Peripheral' => 'keyboard not working',
    'Network' => 'power issue on network point',
    'Cable' => 'cable fault in service bay',
    _ => 'part replaced during service visit',
  };
}

String _usedQuantityFor(Map<String, dynamic> part) {
  final stock = part['stock'] as int;
  if (stock <= 2) return '$stock';
  return '1';
}
