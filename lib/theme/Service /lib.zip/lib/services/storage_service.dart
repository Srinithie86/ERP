import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static Future<void> saveUser(Map data) async {
    final prefs = await SharedPreferences.getInstance();

    final userId = data["user_id"] ?? data["uid"] ?? data["id"];
    if (userId != null) {
      await prefs.setString("uid", userId.toString());
    }

    final cid = data["cid"];
    if (cid != null) {
      await prefs.setString("cid", cid.toString());
    }

    final token = data["token"];
    if (token != null) {
      await prefs.setString("token", token.toString());
    }
    
    if (data.containsKey("cus_id")) {
      await prefs.setString("cus_id", data["cus_id"].toString());
    }
    if (data.containsKey("engineer_id")) {
      await prefs.setString("engineer_id", data["engineer_id"].toString());
    }
    if (data.containsKey("role_id")) {
      await prefs.setString("role_id", data["role_id"].toString());
    }

    await prefs.setBool("logged_in", true);

    // Debug
    print("Saved UID: ${data["user_id"]}");
    print("Saved CID: ${data["cid"]}");
    print("Saved TOKEN: ${data["token"]}");
  }

  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool("logged_in") ?? false;
  }

  static Future<String?> getUid() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("uid");
  }

  static Future<String?> getCid() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("cid");
  }

  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("token");
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
}