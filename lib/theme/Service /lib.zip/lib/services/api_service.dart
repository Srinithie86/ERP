﻿import 'dart:convert';
import 'package:http/http.dart' as http;
import 'device_service.dart';

class ApiService {
  static const String baseUrl =
      "https://erpsmart.in/total/api/m_api/";

  static Future<dynamic> login({
    required String mobile,
    required String lat,
    required String lon,
  }) async {
    String deviceId = await DeviceService.getDeviceId();

    var response = await http.post(
      Uri.parse(baseUrl),
      body: {
        "type": "5001",
        "lt": lat,
        "ln": lon,
        "device_id": deviceId,
        "mobile": mobile,
      },
    );

    print("LOGIN: ${response.body}");
    return jsonDecode(response.body);
  }

  // VERIFY (5002)
  static Future<dynamic> verifyOtp({
    required String mobile,
    required String otp,
    required String lat,
    required String lon,
    required String cid,
    required String token,
  }) async {
    String deviceId = await DeviceService.getDeviceId();

    var response = await http.post(
      Uri.parse(baseUrl),
      body: {
        "type": "5002",
        "lt": lat,
        "ln": lon,
        "device_id": deviceId,
        "mobile": mobile,
        "cid": cid,
        "otp": otp,
        "token": token,
      },
    );

    print("VERIFY: ${response.body}");
    return jsonDecode(response.body);
  }
}